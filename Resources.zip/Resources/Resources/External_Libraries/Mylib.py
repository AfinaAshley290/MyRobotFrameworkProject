
#  Copyright 2013 SWIFT Irving Mereau


import re

"""import time
from datetime import date"""


from fnmatch import fnmatchcase

from random import randint

from string import ascii_lowercase, ascii_uppercase, digits



from robot.version import get_version


class Mylib:


    """A test library for string manipulation and verification."""



    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    ROBOT_LIBRARY_VERSION = get_version()

    """Returns the group specified in 3rd azrgument"""

    def Get_Group_From_Regex(self, string, regex, id):

        print string
        
        print regex

        myregex = re.compile(regex)
        
        print myregex
        
        r       =    myregex.search(string)

        print r

        print r.groups()[int(id)] 

        return r.groups()[int(id)]
        
        
        
        
    def Get_List_From_String_Lines(self, string):

        print string
        
        list = string.splitlines()
        
        return list
    
    
    
    def Get_List_From_String_Pipes(self, string):

        print string
        
        list = string.split("|")
        
        return list


    def Get_List_From_String_Commas(self, string):

        print string
        
        list = string.split(",")
        
        return list
            

    """def Get_formatted_Time(self):

        d = date.fromordinal(730920)

        return d.strftime("%d %b %Y")"""
        

    
