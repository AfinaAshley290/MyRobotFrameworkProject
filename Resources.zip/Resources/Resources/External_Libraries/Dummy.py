def ApproveDraft(userEmail, bic, categoryAcronym, comment): pass

def ApprovePreDraft(userEmail, bic, categoryAcronym, comment): pass

def ApproveSWP(userEmail, bic): pass

def DeleteUser(entityGroup, userEmail): pass

def DenyAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, note): pass

def GenerateNewSWP(userEmail, bic): pass

def GrantAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, note): pass

def GrantSWPAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, grants, note): pass

def InviteMultiProfileUser(entityGroup, userEmail, userBic8, rolesToAssign, entities): pass

def InviteMultiProfileUserSkipEmailLookup(entityGroup, userEmail, userBic8, rolesToAssign, entities): pass

def InviteUser(entityGroup, userEmail, rolesToAssign, entities, entityGroupwideroles): pass

def ProgressWorkflowStartedFromBankUpTo(bic, categoryAcronym, finalStatus): pass

def ProgressWorkflowStartedFromSWIFTUpTo(bic, categoryAcronym, finalStatus): pass

def ProposeDraftForPublication(userEmail, bic, categoryAcronym, comment, checkList): pass

def ProposeDraftForSubmission(userEmail, bic, categoryAcronym, comment): pass

def ProposePreDraftForSubmission(userEmail, bic, categoryAcronym, comment): pass

def PublishDraft(userEmail, bic, categoryAcronym, message): pass

def PublishSWP(userEmail, bic, SWPCategoryAcronym): pass

def QualifyDraft(userEmail, bic, categoryAcronym, checkList): pass

def ReconfirmAlertFired(bic, categoryAcronym): pass

def ReconfirmFolder(userEmail, bic, categoryAcronym, comment): pass

def RejectDraftPublication(userEmail, bic, categoryAcronym, comment): pass

def RejectDraftQualification(userEmail, bic, categoryAcronym, comment): pass

def RejectDraftSubmission(userEmail, bic, categoryAcronym, comment): pass

def RejectPreDraftSubmission(userEmail, bic, categoryAcronym, comment): pass

def RejectSWPAllAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, note): pass

def ReplyToDocumentQuery(userEmail, bic, categoryAcronym, docTypeAcronym, docLanguage, docQueryType, requestingBic, note): pass

def ReplyToMessageQuery(userEmail, bic, categoryAcronym, messageTopic, requestingBic, note): pass

def RequestAccess(userEmail, requestingEntitiesBic, grantingEntityBic, note): pass

def RequestSWPAccess(userEmail, accesses, grantingEntityBic, note): pass

def ReserveTask(userEmail, taskType, bic, categoryAcronym): pass

def ReserveTaskFreeText(userEmail, taskType, bic, freetext): pass

def RevokeAccess(userEmail, revokedEntitiesBic, grantingEntityBic, note): pass

def RevokeSWPAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, revokes): pass

def SendDocumentQuery(userEmail, bic, categoryAcronym, docTypeAcronym, docLanguage, docDescription, docQueryType, requestingBic, note): pass

def SendMessageQuery(userEmail, bic, categoryAcronym, messageTopic, requestingBic, note): pass

def SubmitDraft(userEmail, bic, categoryAcronym, comment): pass

def SubmitPreDraft(userEmail, bic, categoryAcronym, comment): pass

def SurrenderAccess(userEmail, surrendingEntitiesBic, requestingEntitiesBic, grantingEntityBic, note): pass

def SurrenderSWPAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, surrenders): pass

def TakeOverTask(userEmail, taskType, bic, categoryAcronym): pass

def UnreserveTask(taskOwnerEmail, taskType, bic, categoryAcronym): pass

def UnreserveTaskFreeText(taskOwnerEmail, taskType, bic, freetext): pass

def UpdateEnableDisableSwiftTakeover(entityGroupName, enabled): pass

def UpdatePreferences(entityGroup, submission4eyes, publication4eyes, freeFormatOutboundCommSupported, takeOverBySwiftSupported, inviteFollowEnabled, counterpartyNotificationsEnabled, adverseMediaActive): pass

def addCoveredByEntity(bic_covered_entity): pass

def addEntityToGroup(name, bic11): pass

def addOperationalPanelNote(userEmail, bic, categoryAcronym, noteText): pass

def addQualificationIssueToDocument(userEmail, bic, categoryAcronym, documentAcronym, qualificationIssueTypeCodes, note): pass

def addQualificationIssueToDocumentType(userEmail, bic, categoryAcronym, documentTypeAcronym, qualificationIssueTypeCodes, note): pass

def addQualificationIssueToField(userEmail, bic, categoryAcronym, fieldCode, qualificationIssueTypeCodes, note): pass

def cleanCaches(): pass

def cleanServerCaches(): pass

def createDraft(userEmail, bic, categoryAcronym, dataJSON): pass

def createGroup(name, adminProfileId1, adminProfileId2, bic11, soldTos, swiftProfileBic11): pass

def deleteDocument(userEmail, bic, categoryAcronym, docTypeAcronym, docLanguage, docDescription): pass

def deleteDraft(userEmail, bic, categoryAcronym): pass

def downloadAccessGrantsGiven(userEmail): pass

def downloadAccessGrantsReceived(userEmail): pass

def downloadProfilePermissionsGiven(userEmail): pass

def downloadProfilePermissionsReceived(userEmail): pass

def linkDocumentType(userEmail, bic, categoryAcronym, docTypeAcronymTolink): pass

def markEntityForDeletion(bic11): pass

def removeCoveredByEntity(bic_covered_entity): pass

def rescheduleAllJobs(): pass

def unlinkDocumentType(userEmail, bic, categoryAcronym, docTypeAcronymToUnlink): pass

def updateConfigurationSetting(key, value): pass

def updateGroup(name, bic11ToAdd, bic11ToRemove, swiftProfileBicToAdd, swiftProfileBicToRemove): pass

def uploadDocument(userEmail, bic, categoryAcronym, docTypeAcronym, language, description, expirationDateString): pass

def uploadDocumentAddAnotherLanguage(userEmail, bic, categoryAcronym, docTypeAcronym, language, originalDocDescription): pass

def uploadDocumentAddEnglishTranslation(userEmail, bic, categoryAcronym, docTypeAcronym, originalDocDescription): pass
