import ldap, sys
from datetime import date

def PythonChangePassword(UserEmail):
    try:
        l=ldap.open('bedset20', port= 20391)
        l.protocol_version= ldap.VERSION3
        username = "cn=Directory Manager"
        password = "SdC9876-"
        l.simple_bind(username, password)
    except ldap.LDAPError, e:
        print e

## The next lines will also need to be changed to support your search requirements and directory
    baseDN = "o=swift.com"
    searchScope = ldap.SCOPE_SUBTREE
## retrieve all attributes - again adjust to your needs - see documentation for more options
    retrieveAttributes = None

# prepare our data
    searchFilter = "mail="+UserEmail+"*"
    todayStr= date.today().strftime("%Y-%m-%dT00:00:00Z")
    mod_attrs =[(ldap.MOD_REPLACE,'userPassword','fftZtQv8wHFcbWGmWwxortab!'),
                (ldap.MOD_REPLACE,'obpasswordchangeflag','false'),
                (ldap.MOD_REPLACE,'obpasswordcreationdate',todayStr),
				(ldap.MOD_REPLACE,'oblockouttime','0'),
				(ldap.MOD_REPLACE,'oblogintrycount','0'),
				(ldap.MOD_REPLACE,'obuseraccountcontrol','ACTIVATED'), 
                ]

# search and replace :-)
    try:
        ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
        result_set = []
        while 1:
            result_type, result_data = l.result(ldap_result_id, 0)
            if (result_data == []):
                break
            else:
                if result_type == ldap.RES_SEARCH_ENTRY:
                    # the current DN is here
                    print result_data[0][0]
                    # apply the modification
                    l.modify_s(result_data[0][0],mod_attrs)
                    print "Paswords have been reset"
    except ldap.LDAPError, e:
        print e

def PythonChangePasswordToSDC(UserEmail):
    try:
        l=ldap.open('bedset20', port= 20391)
        l.protocol_version= ldap.VERSION3
        username = "cn=Directory Manager"
        password = "SdC9876-"
        l.simple_bind(username, password)
    except ldap.LDAPError, e:
        print e

## The next lines will also need to be changed to support your search requirements and directory
    baseDN = "o=swift.com"
    searchScope = ldap.SCOPE_SUBTREE
## retrieve all attributes - again adjust to your needs - see documentation for more options
    retrieveAttributes = None

# prepare our data
    searchFilter = "mail="+UserEmail+"*"
    todayStr= date.today().strftime("%Y-%m-%dT00:00:00Z")
    mod_attrs =[(ldap.MOD_REPLACE,'userPassword','SdC9876-'),
                (ldap.MOD_REPLACE,'obpasswordchangeflag','false'),
                (ldap.MOD_REPLACE,'obpasswordcreationdate',todayStr),
				(ldap.MOD_REPLACE,'oblockouttime','0'),
				(ldap.MOD_REPLACE,'oblogintrycount','0'),
				(ldap.MOD_REPLACE,'obuseraccountcontrol','ACTIVATED'), 
                ]

# search and replace :-)
    try:
        ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
        result_set = []
        while 1:
            result_type, result_data = l.result(ldap_result_id, 0)
            if (result_data == []):
                break
            else:
                if result_type == ldap.RES_SEARCH_ENTRY:
                    # the current DN is here
                    print result_data[0][0]
                    # apply the modification
                    l.modify_s(result_data[0][0],mod_attrs)
                    print "Paswords have been reset"
    except ldap.LDAPError, e:
        print e

def PythonChangePasswordTo(UserEmail, Password1, Environment):
    try:
        env = str(Environment)
        username = "cn=Directory Manager"
        password = "SdC9876-"
        if env == "PAC":
            print('Change password of user on PAC environment!')
            password = "SdC9876-"
            l=ldap.open('bedset20', port= 20391)
            l.protocol_version= ldap.VERSION3
        else:
            print('Change password of user on SI environment!')
            password = "BIpo?N6:"
            l=ldap.open('bedsei20', port= 20391)
            l.protocol_version= ldap.VERSION3
        l.simple_bind(username, password)
        password_string=str(Password1)
        env = str(Environment)
    except ldap.LDAPError, e:
        print e

## The next lines will also need to be changed to support your search requirements and directory
    baseDN = "o=swift.com"
    searchScope = ldap.SCOPE_SUBTREE
## retrieve all attributes - again adjust to your needs - see documentation for more options
    retrieveAttributes = None

# prepare our data
    searchFilter = "mail="+UserEmail+"*"
    todayStr= date.today().strftime("%Y-%m-%dT00:00:00Z")
    mod_attrs =[(ldap.MOD_REPLACE,'userPassword',password_string),
                (ldap.MOD_REPLACE,'obpasswordchangeflag','false'),
                (ldap.MOD_REPLACE,'obpasswordcreationdate',todayStr),
				(ldap.MOD_REPLACE,'oblockouttime','0'),
				(ldap.MOD_REPLACE,'oblogintrycount','0'),
				(ldap.MOD_REPLACE,'obuseraccountcontrol','ACTIVATED'),
                ]

# search and replace :-)
    try:
        ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
        result_set = []
        while 1:
            result_type, result_data = l.result(ldap_result_id, 0)
            if (result_data == []):
                break
            else:
                if result_type == ldap.RES_SEARCH_ENTRY:
                    # the current DN is here
                    print result_data[0][0]
                    # apply the modification
                    l.modify_s(result_data[0][0],mod_attrs)
                    print "Passwords have been reset"
    except ldap.LDAPError, e:
        print e

def PythonDeleteUser(UserEmail):
    try:
        l=ldap.open('bedset20', port= 20391)
        l.protocol_version= ldap.VERSION3
        username = "cn=Directory Manager"
        password = "SdC9876-"
        l.simple_bind(username, password)
    except ldap.LDAPError, e:
        print e

## The next lines will also need to be changed to support your search requirements and directory
    baseDN = "o=swift.com"
    searchScope = ldap.SCOPE_SUBTREE
## retrieve all attributes - again adjust to your needs - see documentation for more options
    retrieveAttributes = None

# prepare our data
    searchFilter = "mail="+UserEmail+"*"
    todayStr= date.today().strftime("%Y-%m-%dT00:00:00Z")
    mod_attrs =[(ldap.MOD_REPLACE,'userPassword','fftZtQv8wHFcbWGmWwxortab!'),
                (ldap.MOD_REPLACE,'obpasswordchangeflag','false'),
                (ldap.MOD_REPLACE,'obpasswordcreationdate',todayStr),
                ]

# search and replace :-)
    try:
        ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
        result_set = []
        while 1:
            result_type, result_data = l.result(ldap_result_id, 0)
            if (result_data == []):
                break
            else:
                if result_type == ldap.RES_SEARCH_ENTRY:
                    # the current DN is here
                    print result_data[0][0]
                    # apply the modification
                    l.delete_s(result_data[0][0])
                    print "User was deleted from ldap"
    except ldap.LDAPError, e:
        print e
		
		
def GetSDCProfileId(UserEmail, Environment):
    try:
        env = str(Environment)
        username = "cn=Directory Manager"
        password = "SdC9876-"
        if env == "PAC":
            print('Get SdC ID on PAC environment!')
            password = "SdC9876-"
            l=ldap.open('bedset20', port= 20391)
            l.protocol_version= ldap.VERSION3
        else:
            print('Get SdC ID on SI environment!')
            password = "BIpo?N6:"
            l=ldap.open('bedsei20', port= 20391)
            l.protocol_version= ldap.VERSION3
        #password = "SdC9876-"
        l.simple_bind(username, password)
        env = str(Environment)
    except ldap.LDAPError, e:
        print e

## The next lines will also need to be changed to support your search requirements and directory
    baseDN = "ou=profile, o=swift.com"
    searchScope = ldap.SCOPE_SUBTREE
## retrieve all attributes - again adjust to your needs - see documentation for more options
    retrieveAttributes = None
    SwiftProfileId = None
	
# prepare our data
    searchFilter = "mail="+UserEmail+"*"

# search and get value
    retry=10
    
    while retry >0:
        ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
        result_type, result_data = l.result(ldap_result_id, 0)
        if not result_data:
            print'no result data: %s, result_type: %s' % (result_data, result_type)
            retry = retry-1
            print 'retry %s' % retry
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                print result_data[0][0]
                try:
                    email = result_data[0][1]['mail'][0]
                    SwiftProfileId = result_data[0][1]['swiftProfileId'][0]
                    bic = result_data[0][1]['swiftBicId'][0]
                    print "Found user: %s, %s, %s" % (email, bic, SwiftProfileId)
                    break
                except ldap.LDAPError, e:
                    print e
    return SwiftProfileId

#PythonChangePassword("marek.hocko@swift.com")
#PythonChangePasswordTo("pac.luca.guidolin@swift.com","Abcd1234-","SI")
GetSDCProfileId("pac.kyc.administrator1@soge.com","CI")

