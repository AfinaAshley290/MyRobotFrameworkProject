import poplib
import email
from email import parser
from email import MIMEBase, MIMEMultipart, MIMEText, Encoders, Header, message_from_string, Charset
import quopri
import logging
import re

#needs to be renamed
def GetEmailBodyFromLastReceivedEmail(UserEmail):
    #Establish connection https://10.15.3.48/owa/ with user and password
    connection = poplib.POP3_SSL("10.4.128.88")
    print connection.user("mailpac")
    print connection.pass_("SdC9876-")
    try:
        #Get total number of messages and size"
        (numMsgs, totalSize) = connection.stat()
        print "numMsgs: ", numMsgs
        if numMsgs == 0:
            print "No Mails in mailbox"
        else:
            #if there are messages in email
            match_number=0
            #next cycle is looking for match of User email in email folder
            while numMsgs>0:        
                email_retrieve = connection.retr(numMsgs)[1]
                email_retrieve_string = str(email_retrieve)
                #I am looking for match of message with userEmail value
                match = re.search(UserEmail,email_retrieve_string)
                if match:
                    print "this is it: ", email_retrieve_string
                    m_body = email_retrieve_string
                    #if m_body:
                    #found = m_body.group(1)
                    #body_text_decoded = str((found.replace("'","")).replace("<b>","").replace("<p>","").replace("</b>","").replace("<body>","").replace("<html>","").replace("</html>","").replace("</body>",""))
                    print "body of the message is:", email_retrieve_string
                    return email_retrieve_string
                    #m_body1 search for specific body as encoding of email is different. See Jira: IAM-4679
                    #m_body1 = re.search('charset=us-ascii">(.+?)]', email_retrieve_string)
                    #if m_body1:
                    #    found = m_body1.group(1)
                    #    body_text_decoded = str((found.replace("</p>","")).replace("<b>","").replace("<p>","").replace("</b>","").replace("<body>","").replace("<html>","").replace("</html>","").replace("</body>",""))
                    #    print "body of the message is:", body_text_decoded
                    #    return body_text_decoded    
                  #I am calculating how many matches I have
                    match_number=match_number+1
                    numMsgs = 0
                else:
                    #print "I didn't find match"
                    numMsgs=numMsgs-1
            print "number of positive match is", match_number

    finally:
        print connection.quit()

def GetLinkFromEmail(UserEmail,subject):
    #Establish connection https://10.15.3.48/owa/ with user and password
    connection = poplib.POP3_SSL("10.4.128.88")
    print connection.user("mailpac")
    print connection.pass_("SdC9876-")
    try:
        #Get total number of messages and size"
        (numMsgs, totalSize) = connection.stat()
        print "numMsgs: ", numMsgs
        if numMsgs == 0:
            print "No Mails in mailbox"
        else:
            #if there are messages in email
            match_number=0
            twenty_messages=500
            while twenty_messages>0:
                email_retrieve = connection.retr(numMsgs)[1]
                email_retrieve_string = str(email_retrieve)
                #I am looking for match of message with userEmail value
                match = re.search(UserEmail,email_retrieve_string)
                if match:
                    #I am calculation how many matches I have
                    match_number=match_number+1
                    #print "this message include your string you find", connection.top(numMsgs,20)
                    message=str(connection.top(numMsgs,20))
                    #below I am searching for link in message - xpath represents link (http or ftp or https)
                    match_subject=re.search(subject,message)
                    if match_subject:
                        match1=re.search("(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?",message)
                        if match1:
                            print "this is link you have to use for reset password", match1.group()
                            twenty_messages=0
                            #I return link I extracted from message in previous steps
                            return match1.group()
                        else:
                            print "in this email there is no link"
                    #need to add condition for stopping search
                    #extract link
                    else:
                        numMsgs = numMsgs-1
                        twenty_messages=twenty_messages-1
                else:
                    #print "I didn't find match"
                    numMsgs=numMsgs-1
                    twenty_messages=twenty_messages-1
            print "number of positive match is", match_number

    finally:
        print connection.quit()        

def GetOTPFromEmail(UserEmail,subject):
    #Establish connection https://10.15.3.48/owa/ with user and password
    connection = poplib.POP3_SSL("10.4.128.88")
    print connection.user("mailpac")
    print connection.pass_("SdC9876-")
    try:
        #Get total number of messages and size"
        (numMsgs, totalSize) = connection.stat()
        print "numMsgs: ", numMsgs
        if numMsgs == 0:
            print "No Mails in mailbox"
            return "No Mails in mailbox"
        else:
            #if there are messages in email
            match_number=0
            messages_checked=0
            while numMsgs>0:
                email_retrieve = connection.retr(numMsgs)[1]
                email_retrieve_string = str(email_retrieve)
                #I am looking for match of message with userEmail value
                match = re.search(UserEmail,email_retrieve_string)
                if match:
                    #I am calculation how many matches I have
                    match_number=match_number+1
                    #print "this message include your string you find", connection.top(numMsgs,20)
                    print "this is email content", email_retrieve_string
                    #message=str(connection.top(numMsgs,20))
                    message=str(email_retrieve_string)
                    #below I am searching for OTP in message - 
                    match_subject=re.search(subject,message)
                    if match_subject:
                        #print message
                        match1=re.search(">([0-9]{6})",message)
                        #match1.group()= otppassword
                        print "otp= ", match1.group()[1:7]
                        return match1.group()[1:7]
                    else:
                        numMsgs = numMsgs-1
                else:
                    #print "I didn't find match"
                    messages_checked=messages_checked+1
                    numMsgs=numMsgs-1
                    if messages_checked>1000:
                        print "Sorry I checked: ",messages_checked, " messages but couldn't find your message"
                        numMsgs=0
            print "number of positive match is", match_number

    finally:
        print connection.quit() 

def DeleteEmail(UserEmail):
    #Establish connection https://10.15.3.48/owa/ with user and password
    connection = poplib.POP3_SSL("10.4.128.88")
    print connection.user("mailpac")
    print connection.pass_("SdC9876-")
    try:
        #Get total number of messages and size"
        (numMsgs, totalSize) = connection.stat()
        print "numMsgs: ", numMsgs
        if numMsgs == 0:
            print "No Mails in mailbox"
        else:
            #if there are messages in email
            match_number=0
            messagesTodelete=26800
            while messagesTodelete>0:
                    connection.dele(numMsgs)
                    numMsgs=numMsgs-1
                    #print "I am here"
                    messagesTodelete=messagesTodelete-1
                       
            print "number of positive match is", match_number

    finally:
        print connection.quit() 


#add def for search for link in body of message
#add return Subject of email
#delete email
#check time and date of received mesage
 
#GetLinkFromEmail("IDM_AutomationAdmin1@ubs-be.com","Delegation request")
#GetEmailBodyFromLastReceivedEmail("pac.benoit.barzin@swift.com")
#GetEmailBodyFromLastReceivedEmail("IDM_AutomationAdmin2@ubs-ch.com")
#GetEmailBodyFromLastReceivedEmail("IDM_AutomationAdmin1@ubs-be.com")
#GetEmailBodyFromLastReceivedEmail("pac_user1@swift.com")
#GetEmailBodyFromLastReceivedEmail("pac.marek.hocko@swift.com")
#GetLinkFromEmail("pac.benoit.barzin@swift.com","Reset Password Ping User Notification")
#GetOTPFromEmail("si.11436340229si.non_connected_Use1@test.com","2-step verification code")
#GetOTPFromEmail("si.1435144435IDM_AutomationAdmin@citi.com","2-step verification activation")
#DeleteEmail("test")