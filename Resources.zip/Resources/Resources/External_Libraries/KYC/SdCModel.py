def dump(obj):
    myStr = []
    for attr in dir(obj):
        if attr[0] != '_':
            myStr += ["%s => %s" % (attr, str(getattr(obj, attr))),]
    return '\n'.join(myStr)
class SdCUser():
    def __init__(self,email,bic,passwd):
        self.email=email
        self.password=passwd
        self.bic=bic
        self.profileId=""
        self.firstName=""
        self.lastName=""
        self.isMultiprofile=False
    def __str__(self):
        return dump(self)
class SdCIDMUser():
    """
    It's an IDM user with all it's profiles. Generaly populated from ldap call.
    """
    def __init__(self,email,password=""):
        self.email=email
        self.password=password
        self.firstName=""
        self.lastName=""
        self.loadedFromLdap=False
        self.profileIds={}
    def isMultiprofile(self):
        if len(self.profileIds)>1:
            return True
        else:
            return False
    def getProfileIdForBIC(self,bic=""):
        if bic and bic in self.profileIds.keys():
            return [bic,self.profileIds[bic]]
        elif self.profileIds:
            return [self.profileIds.items()[0][0],self.profileIds.items()[0][1]]
        else:
            return []
    def setProfileId(self,bic,profileId):
        self.profileIds[bic]=profileId
    def getSdCUser(self,bic=""):
        user = SdCUser(self.email,bic,self.password)
        user.firstName = self.firstName
        user.lastName=self.lastName
        profId=self.getProfileIdForBIC(bic)
        if profId:
            user.bic=profId[0]
            user.profileId=profId[1]
        if self.isMultiprofile():
            user.isMultiprofile=True
        return user
    def __str__(self):
        return dump(self)