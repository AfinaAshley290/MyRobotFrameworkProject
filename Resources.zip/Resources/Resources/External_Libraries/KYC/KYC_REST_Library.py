# -*- coding: utf-8 -*-
import KYCREST
from KYCSQL import KYCSQL
from KYCREST import KYC,KYCRESTCallException
from robot.libraries.BuiltIn import BuiltIn
from SdCUtils import LogToStdOut,get_script_dir
import os,re,sys,traceback
from KYCENV import KYCEnvironment
from SdCUtils import LogFunctionAccess
import logging

logger = logging.getLogger("KYC_REST_Library")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)

def LogAccess(fn):
    return LogFunctionAccess(fn,logger)
def __getRFResourcePath(relativeSplittedPath):
    resSplitedPath =get_script_dir().split(os.sep)[:-2]
    return os.sep.join(resSplitedPath + relativeSplittedPath)
@LogAccess
def __loadRFVariables(fullfilename):
    """
    Function to load the Robotframework variables
    """
    f = open(fullfilename,'r')
    varName = ''
    while 1:
        s = f.readline()
        if not s: break
        if s[-1] =="\n": s = s[:-1]
        if s and s[0]=="$":
            data = re.split(' +',s)
            varName = data[0][2:-1]
            rfVar[varName]=data[1]
        elif s and s[0]=="@":
            data = re.split(' +',s)
            varName = data[0][2:-1]
            rfVar[varName]=data[1:]
        elif s and s[:3]=='...':
            data = re.split(' +',s)
            rfVar[varName] +=data[1:]
    f.close()
@LogAccess
def initKYC():
    global kycsql
    global kycrest

    if not rfVar:
        print 'KYC_REST_Library - initKYC - Loading RF vars'
        __loadRFVariables(__getRFResourcePath(['Generic','generic_res.txt']))
    envi=''

    if 'ENV' in os.environ.keys():
        print 'ENV from environ - ' + os.environ['ENV']
        if os.environ['ENV'] == 'CI-PAC':
            envi = 'PAC_CI'
        elif os.environ['ENV'] == 'PAC':
            envi = 'PAC'
    else:
        print 'ENV from ROBOT - ' + rfVar['ENV']
        if rfVar['ENV'] == 'CI-PAC':
            envi = 'PAC_CI'
        elif rfVar['ENV'] == 'PAC':
            envi = 'PAC'
    #envi='PAC'
    logger.debug( "KYC_REST_Library - env - %s" % envi)
    env = KYCEnvironment.getEnvironment(envi)
    # add RF users
    env.documentPath = __getRFResourcePath(['tmp_upload_docs',''])
    kycrest = KYC(env)
    kycsql = KYCSQL(env)

@LogAccess
def download_Access_Given_Report_For_User(userAlias):
    try:
        return kycrest.downloadAccessGivenReportForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download Access Given Report - %s" % (sys.exc_info()[0],))
@LogAccess    
def download_Access_Received_Report_For_User(userAlias):
    try:
        return kycrest.downloadAccessReceivedReportForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download Access Received Report - %s" % (sys.exc_info()[0],))
@LogAccess    
def download_SWP_Access_Given_Report_For_User(userAlias):
    try:
        return kycrest.downloadSWPAccessGivenReportForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download SWP Access Given Report - %s" % (sys.exc_info()[0],))
@LogAccess    
def download_SWP_Access_Received_Report_For_User(userAlias):
    try:
        return kycrest.downloadSWPAccessReceivedReportForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download SWP Access Received Report - %s" % (sys.exc_info()[0],))
@LogAccess
def download_Data_Consumption_For_User(userAlias):
    try:
        return kycrest.downloadDataConsumptionForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download Data Consumption Report - %s" % (sys.exc_info()[0],))
@LogAccess   
def download_Missing_Roles_For_User(userAlias):
    try:
        return kycrest.downloadMissingRolesForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download Missing Roles Report - %s" % (sys.exc_info()[0],))        
@LogAccess
def download_User_Roles_Assignment_For_User(userAlias):
    try:
        return kycrest.downloadUserRoleAssignmentForUser(userAlias)
    except:                        
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download User Roles Assignmnet Report - %s" % (sys.exc_info()[0],))  
@LogAccess
def download_Data_Contribution_Activities_For_User(userAlias):
    try:
        return kycrest.downloadDataContributionActivitiesForUser(userAlias)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot download Data Contribution Activities Report - %s" % (sys.exc_info()[0],))  
@LogAccess
def count_Filtered_Report_Records(report,sqlFilter=""):
    print 'KYC_REST_Library - report: ', report
    print 'KYC_REST_Library - sqlFilter: ', sqlFilter
    try:
        count = 0
        con = kycrest.inMemSqlite3Connection
        cur  = con.cursor()
        if sqlFilter:
            sql = "select count(*) from %s where %s;" % (report,sqlFilter)
        else:
            sql = "select count(*) from %s;" % report
        cur.execute(sql)
        res = cur.fetchone()
        cur.close()
        count = res[0]
        return count
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot count Report records - %s" % (sys.exc_info()[0],))
@LogAccess
def verify_report_exist(report, sqlFilter=""):
    print 'KYC_REST_Library - report: ', report
    print 'KYC_REST_Library - sqlFilter: ', sqlFilter
    try:
        count = 0
        con = kycrest.inMemSqlite3Connection
        cur  = con.cursor()
        if sqlFilter:
            sql = "select count(*) from %s where %s;" % (report,sqlFilter)
        else:
            sql = "select count(*) from %s;" % report
        cur.execute(sql)
        res = cur.fetchone()
        cur.close()
        count = res[0]
        return "Passed"
    except:
        return "Fail"
@LogAccess
def verify_report_information(info, report, sqlFilter=""):
    print 'KYC_REST_Library - report: ', report
    print 'KYC_REST_Library - sqlFilter: ', sqlFilter
    try:
        count = 0
        con = kycrest.inMemSqlite3Connection
        cur  = con.cursor()
        if sqlFilter:
            sql = "select count(*) from %s where %s;" % (report,sqlFilter)
        else:
            sql = "select %s from %s;" % (info,report)
        cur.execute(sql)
        res = cur.fetchone()
        cur.close()
        count = res[0]
        return "Pass"
    except:
        return "Fail"
@LogAccess
def run_SQL(sqlConfigFile,params=[],returnDict=False):
    try:
        return kycsql.runSQL(__getRFResourcePath(['shell_scripts','SQL','']) + sqlConfigFile, params, returnDict)
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot run SQL - %s" % (sys.exc_info()[0],))    
@LogAccess
def getFolderData(userAlias,bic,category,version):
    print 'KYC_REST_Library - getFolderData'
    try:
        try:
            res = kycrest.getFolderVersion(userAlias,bic,category,version)
        except KYCRESTCallException, e:
            res = e
        if not res.error and res.data and "data" in res.data.keys():
            return ['SUCCESS',res.data["data"]["data"]]
        else:
            return ['ERROR',res.data]
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot get folder data - %s" % (sys.exc_info()[0],)) 
@LogAccess   
def getFullOMSJson(prefix,nbrOfShareholdingCompanies='1',nbrOfShareholders='1',nbrOfKeyControllers='1'):
    try:
        myJson = kycrest.getFullOMSJson(prefix,int(nbrOfShareholdingCompanies),int(nbrOfShareholders),int(nbrOfKeyControllers))
        return myJson
    except:
        print "KYC_REST_Library - Unexpected error:", sys.exc_info()
        print traceback.format_exc()
        raise AssertionError("Unexpected error: Cannot create FULL OMS Json - %s" % (sys.exc_info()[0],)) 
kycrest=None

kycsql=None
rfVar={}
ROBOT_LIBRARY_SCOPE = 'GLOBAL'
initKYC()
if __name__=='__main__':
    #myJson = getFullOMSJson('HO',2,2,3)
    #print myJson
    table = download_SWP_Access_Given_Report_For_User('pac.kyc.granter1@cpm.co.ma')
    print table
    print count_Filtered_Report_Records(table)
    #ret = getFolderData('pac.kyc.administrator1@rbos.com','CITITNTXXXX','IOC',14)
    #print ret
#     ret = run_SQL('KYC_getEntityIds',['PARB'], returnDict=True)
#     for rec in ret:
#         if 'BIC11'in rec:
#             print rec['BIC11'],rec['ID']



