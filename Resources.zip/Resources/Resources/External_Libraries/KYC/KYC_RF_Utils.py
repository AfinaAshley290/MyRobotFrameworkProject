import json, re
from robot.libraries.BuiltIn import BuiltIn
import logging
# UTILS FUNCTIONs


logger = logging.getLogger("KYC_RF_Utils")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)

def Get_JSON_From_Dictionary(aDict):
    return json.dumps(aDict)
def Add_List_To_Dictionary(aDict,key,*aValue):
    aDict[key]=[val for val in aValue]
    return aDict
def Add_Int_To_Dictionary(aDict,key,aValue):
    aDict[key]=int(aValue)
    return aDict
def getChecklistFromString(checklist):
    print checklist
    return [True if v.upper() == 'TRUE' else False for v in checklist.split("|")]
def Add_Boolean_To_Dictionary(aDict,key,aValue):
    if str(aValue).upper()=='TRUE':
        aDict[key]=True
    else:
        aDict[key]=False
    return aDict
# KYC UI testing keywords
def __filter2regex(filter):
    print "KYC_RF_Utils - in __filter2regex"
    return '.*' + filter.replace(',','.*') + '.*'

def get_webdriver_instance():
    se2lib = BuiltIn().get_library_instance('Selenium2Library')
    return se2lib._current_browser()
def KYC_Get_Row_Elements():
    browser = get_webdriver_instance()
    rows =  browser.find_elements_by_xpath("//*[@id='ROW']")
    if len(rows) == 0 :
        rows =  browser.find_elements_by_xpath("//*[@id='tasks']//tr")
    print "KYC_RF_Utils - Found %s rows" % str(len(rows))
    return rows
       
def KYC_Get_Documents_Row_Elements():
    browser = get_webdriver_instance()
    doclines =  browser.find_elements_by_xpath("//*[@id='draftFolderDocuments']//*[@id='ROW']")
    print "KYC_RF_Utils - Found %s document lines" % str(len(doclines))
    return doclines
def KYC_Get_Task_Elements_By_Regex(regex):
    return KYC_Get_Row_Elements_By_Regex(regex)
def KYC_Get_Request_Elements_By_Regex(regex):
    return KYC_Get_Row_Elements_By_Regex(regex)
def KYC_Get_Event_Elements_By_Regex(regex):
    return KYC_Get_Row_Elements_By_Regex(regex)
def KYC_Get_Documents_Row_Elements_By_Regex(regex):
    regex = '^' + regex + '$'
    print regex
    filtered_doclines=[]
    doclines =  KYC_Get_Documents_Row_Elements()
    for line in doclines:
        innerHTML = line.get_attribute('outerHTML').replace("\n","")        
        if re.match(regex,innerHTML):
            filtered_doclines.append(line)
    return filtered_doclines
    
def KYC_Get_Row_Elements_By_Regex(regex):
    regex = '^' + regex + '$'
    logger.debug( regex)
    filtered_tasks=[]
    tasks =  KYC_Get_Row_Elements()
    for task in tasks:
        innerHTML = task.get_attribute('outerHTML').replace("\n","")
        logger.debug( innerHTML )       
        if re.match(regex,innerHTML):
            filtered_tasks.append(task)
    return filtered_tasks
def KYC_Manage_Access_Click_On_Request_Access(bic):
    rows = KYC_Get_Row_Elements_By_Regex(".*%s.*" % bic)
    if rows:
        rows[0].click()
    else:
        raise AssertionError("KYC_RF_Utils - %s exist !" % bic)
def KYC_Click_On_Task_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    if tasks:
        tasks[0].click()
    else:
        raise AssertionError("KYC_RF_Utils - Task doesn't exist !")
def KYC_Dismiss_Task_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    if tasks:
        tasks[0].find_elements_by_xpath(".//*[@id='dismissTask']")[0].click()
    else:
        raise AssertionError("KYC_RF_Utils - Task doesn't exist !")
def KYC_Click_On_Request_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    if tasks:
        tasks[0].click()
    else:
        raise AssertionError("KYC_RF_Utils - Request doesn't exist !") 
def KYC_Click_On_Event_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    if tasks:
        tasks[0].click()
    else:
        raise AssertionError("KYC_RF_Utils - Event doesn't exist !")    
def KYC_Count_Tasks_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    return len(tasks)
def KYC_Count_Document_Instances_By_Regex(regex):
    instances = KYC_Get_Documents_Row_Elements_By_Regex(regex)
    return len(instances)
def KYC_Count_Requests_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    return len(tasks)
def KYC_Count_Events_By_Regex(regex):
    tasks = KYC_Get_Row_Elements_By_Regex(regex)
    return len(tasks)
def KYC_Count_Tasks_By_Filter(filter):
    tasks = KYC_Get_Row_Elements_By_Regex(__filter2regex(filter))
    return len(tasks)
def KYC_Count_Document_Instances_By_Filter(filter):
    return KYC_Count_Document_Instances_By_Regex(__filter2regex(filter))
def KYC_Count_Requests_By_Filter(filter):
    tasks = KYC_Get_Row_Elements_By_Regex(__filter2regex(filter))
    return len(tasks)
def KYC_Count_Events_By_Filter(filter):
    tasks = KYC_Get_Row_Elements_By_Regex(__filter2regex(filter))
    return len(tasks)

def KYC_Dismiss_Task_By_Filter(filter):
    KYC_Dismiss_Task_By_Regex(__filter2regex(filter))
def KYC_Click_On_Task_By_Filter(filter):
    KYC_Click_On_Task_By_Regex(__filter2regex(filter))
def KYC_Click_On_Request_By_Filter(filter):
    KYC_Click_On_Request_By_Regex(__filter2regex(filter))
def KYC_Click_On_Event_By_Filter(filter):
    KYC_Click_On_Event_By_Regex(__filter2regex(filter))
if __name__=='__main__':
    print getChecklistFromString('True|False|TRUE|TrUE|False|ANything')
