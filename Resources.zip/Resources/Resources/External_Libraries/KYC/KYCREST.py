# -*- coding: utf-8 -*-
import json
from SdCRequests import RESTRequest, HTTPCallException, ConnectionException
import KYCENV
from SdCUtils import LogToStdOut as log
from SdCUtils import extractCSVToSqlite3DB
#from SdCSQLUtils import SQLViaCxOracle
from SdCSQLUtils import SQLViaSSH
import pprint
import sqlite3
import time
from SdCModel import dump
import KYCData
import logging
#from KYC_dao import *
import os

logger = logging.getLogger("KYCREST")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)

extentionMimeType = {'jpg':'image/jpeg',
                   'tiff':'image/tiff',
                   'pdf':'application/pdf',
                   'png':'image/png'}

def jsonReqWithRetry(fn): 
    """
    Do a json request to KYC server and retry (3 times) in case of error. Tu be use as a wrapper to postJson, getJon, ... 
    """
    def wrapped_fn(*a, **kw):
        retry = 3
        logger.debug("%s, %s, %s" % (str(fn), str(a), str(kw)))
        res = None
        while retry:
            logger.debug('RETRY: %d' % retry)
            retry -= 1
            res = fn(*a, **kw)
            
            if res.status != 'SUCCESS' and res.type == 'HTML':
                logger.error( "Unknown error, got HTML instead of JSON, retrying call to server ...")
                logger.error(res.text)
                time.sleep(5)
            elif res.status != 'SUCCESS' and res.type == 'JSON' and 'messageCode' in res.data.keys():
                if res.data['messageCode'] == 'GENERIC_EXCEPTION':
                    logger.error("GENERIC_EXCEPTION error, retrying call to server after sleeping 5 seconds ...")
                    time.sleep(5)
                else:
                    retry = 0
            else:
                retry = 0
        if not res: raise Exception('No result, res in Null !!!')
        if res.status!='SUCCESS':
            raise KYCRESTCallException(res)
        return res
    return wrapped_fn  

class KYCDocument(object):
    def __init__(self,path,filename,name="",documentTypeId="",description="",expirationDate="",language="",documentType="",content_type=None):
        self.filename=filename
        self.name=name
        self.documentType=documentType
        self.acronym=""
        self.id=None
        self.documentTypeId=documentTypeId
        self.description=description
        self.expirationDate=expirationDate
        self.language=language
        self.content_type=content_type
        self.path=path
        self.linkedFromEntityId=None
    def __str__(self):
        return dump(self)

class KYCRESTClient(RESTRequest):
    def __init__(self, environment):
        RESTRequest.__init__(self, environment)
        self.userSimulationMode = {}
    def getUserKey(self,userEmail,userBic):
        key = userEmail
        if userBic: key = userEmail + '@' + userBic
        return key
    def getSimulatedUser(self, userEmail,userBic=""):
        key = self.getUserKey(userEmail,userBic)
        if  key in self.userSimulationMode.keys():
            (alias, bic) = self.userSimulationMode[key]
            if alias:
                return self.env.getSdCUser(alias,bic)
        else:
            return ""
    def setSimulatedUser(self, userEmail,userBic, simulatedUserEmail,simulatedUserBic):
        key = self.getUserKey(userEmail,userBic)
        self.userSimulationMode[key] = [simulatedUserEmail,simulatedUserBic]
    def __getUserAndHeader(self,userEmail,userBic):
        user = self.env.getSdCUser(userEmail,userBic)
        http_add_header = {}
        simulated_user = self.getSimulatedUser(userEmail,userBic)
        if simulated_user:
            http_add_header = {'simulated_sw_profileid':simulated_user.profileId}
        return user,http_add_header
    @jsonReqWithRetry
    def getJson(self, userEmail,userBic, urltrail):
        user,http_add_header = self.__getUserAndHeader(userEmail,userBic)
        return RESTRequest.getJson(self,user, urltrail, http_add_header)
    @jsonReqWithRetry
    def postJson(self, userEmail,userBic, urltrail, data):
        user,http_add_header = self.__getUserAndHeader(userEmail,userBic)
        return RESTRequest.postJson(self,user, urltrail, data, http_add_header)
    @jsonReqWithRetry    
    def uploadFile(self, userEmail,userBic, urltrail, filename,form_fields):
        user,http_add_header = self.__getUserAndHeader(userEmail,userBic)
        return RESTRequest.uploadFile(self,user, urltrail, filename,form_fields,http_add_header) 
    @jsonReqWithRetry     
    def downloadFile(self, userEmail,userBic, urltrail, dir):
        user,http_add_header = self.__getUserAndHeader(userEmail,userBic)
        return RESTRequest.downloadFile(self,user, urltrail, dir,http_add_header) 
        
class KYCConnectionException(ConnectionException):
    def __init__(self, value):
        ConnectionException.__init__(self, value)
class KYCRESTCallException(HTTPCallException):
    def __init__(self, res):
        HTTPCallException.__init__(self, res)

class KYC():
    """
    Main class implementing KYC actions
    """
    def __init__(self, env=KYCENV.KYCEnvironment.getEnvironment()):
        self.env = env
        self.ws = KYCRESTClient(env)
        self.resourcesURL="resources/v1/"
        self.inMemSqlite3Connection = sqlite3.connect(":memory:")
        self.entityIds={}
        self.documentTypes={}
        self.libDir=os.path.dirname(KYCENV.__file__)
    class WorkflowActions:
        SUBMIT,PUBLISH = range(2)
    def __getUserAndBicFromAlias(self,userAlias):
        # user alias could be like pac.kyc.user@company.com@BIC8XXXX
        userParts = userAlias.split('@')
        user = "@".join(userParts[:2])
        bic = ""
        if len(userParts) ==3: bic = userParts[2]
        return  (user,bic)
    def __uploadFile(self, userAlias, bic, category, doc):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        entityId = self.getEntityId(bic)
        urltrail = 'resources/v1/entity/%s/folder/%s/document/upload' % (str(entityId), str(category))
        form_fields={}
        
        form_fields['name']= str(doc.name)
        form_fields['filename']= str(doc.filename)
        form_fields['documentTypeId']= str(doc.documentTypeId)
        form_fields['description']= str(doc.description)
        form_fields['expirationDate']= str(doc.expirationDate)
        form_fields['language']= str(doc.language)
        filename = doc.path + "/" + doc.filename
        
        res = self.ws.uploadFile(userEmail,userBic, urltrail,filename, form_fields)
        if res.status == 'SUCCESS'and res.type == 'JSON':
            data = res.data
            if 'id' in data.keys():
                docid = data['id']
                doctypeid = data['documentTypeId']
                return [docid, doctypeid]
        else:
            raise KYCRESTCallException(res)
    def __downloadReport(self,userAlias,rptType=""):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        logger.info("KYCREST - Start __downloadReport")
        downloadDir = self.env.documentPath + "downloads"
        try:
            logger.debug( "KYCREST - %s is already created ?" % downloadDir)
            os.stat(downloadDir)
        except:
            logger.debug( "KYCREST - Create %s" % downloadDir)
            os.mkdir(downloadDir)
            logger.debug( "KYCREST - Download dir created")
        if rptType == 'activitylog': # added by Hassan Mollah ---report activitylog coming from resources/v1/ not from resources/v1/reports
            urltrail= self.resourcesURL + "" + rptType
        else:
            urltrail= self.resourcesURL + "reports/" + rptType

        logger.info("KYCREST - downloadReport %s" % urltrail)
        res = self.ws.downloadFile(userEmail,userBic,urltrail,downloadDir)
        return downloadDir + '/' + res.data
    def __runSQL(self,sqlFileName,values=[],returnDict=False):
        sqlFilePath = ""
        if os.sep in sqlFileName:
            splitPath = sqlFileName.split(os.sep)
            sqlFileName=splitPath[-1]
            sqlFilePath=os.sep.join(splitPath[:-1])
        with SQLViaSSH(self.env.sshDBServerConnectionParams,self.env.dbConnectionParams,sqlFilePath) as sshsql:
            sshsql.returnDict=returnDict
            sqlret = sshsql.runPreparedSQL(sqlFileName, values=values,recreate=False)
        return sqlret
#     def __runSQL(self,sqlFileName,values=[],returnDict=False):
#         sqlFilePath = ""
#         if os.sep in sqlFileName:
#             splitPath = sqlFileName.split(os.sep)
#             sqlFileName=splitPath[-1]
#             sqlFilePath=os.sep.join(splitPath[:-1])
#         with SQLViaCXOracle(self.env.dbConnectionParams) as sqlrunner:
#             sqlrunner.returnDict=returnDict
#             if sqlFilePath:
#                 sqlrunner.sqlLocalDir=sqlFilePath + os.sep
#             sqlret = sqlrunner.runSQL(sqlFileName, values=values)
#         return sqlret
    
    def getLastFolderStatusAndVersion(self,bic,category):
        ret = self.__runSQL('KYC_Get_Last_Folder_Status_And_Version',[bic,category],returnDict=True)
        if ret:
            return ret[0]
        else:
            return ret
    def getFolderItemId(self,bic,category,version):
        ret = self.__runSQL('KYC_getFolderItemId',[bic,category,version])
        folderItemId = "-1"
        if ret:
            folderItemId = ret[0][0]
        return int(folderItemId)
    def getEntityId(self,bic):
        logger.info('getEntityId')
        if bic not in self.entityIds.keys():
            ret = self.__runSQL('KYC_getEntityIds',[bic[:4],])
            for id,lei,bic11 in ret:
                logger.debug('Adding %s, %s, %s' % (bic11, str(id), lei))
                key = bic11
                if not key: key = lei
                self.entityIds[key]=id
        if bic in self.entityIds.keys():
            return self.entityIds[bic]
        else:
            return None
    def getDocumentTypeId(self,docType):
        if docType not in self.documentTypes.keys():
            ret = self.__runSQL('KYC_getDocumentTypes',[])
            for id,type,name,category,category_name in ret:
                logger.debug( 'Adding %s, %s, %s, %s, %s %s' % (str(id),type,name,category,category_name, 'to docTypes'))
                key = type
                self.documentTypes[key]=id
        if docType in self.documentTypes.keys():
            return self.documentTypes[docType]
        else:
            return None
    def __extractReportToInMemDB(self,reportPath):
        if self.inMemSqlite3Connection:
            self.inMemSqlite3Connection.close()
            self.inMemSqlite3Connection = None
        tableName,self.inMemSqlite3Connection = extractCSVToSqlite3DB(reportPath)
        return tableName
    def __downloadReportAndLoadInMemory(self,userAlias,rptType):
        logger.info("KYCREST - Start __downloadReportAndLoadInMemory")
        reportPath = self.__downloadReport(userAlias,rptType)
        tableName = self.__extractReportToInMemDB(reportPath)
        return tableName
    def downloadAccessGivenReportForUser(self,userAlias):
        return self.__downloadReportAndLoadInMemory(userAlias,rptType = "grants-given")
    
    def downloadAccessReceivedReportForUser(self,userAlias):
        return self.__downloadReportAndLoadInMemory(userAlias,rptType = "grants-received")
    
    def downloadSWPAccessGivenReportForUser(self,userAlias):
        return self.__downloadReportAndLoadInMemory(userAlias,rptType = "swift-profile-grants-given")
    
    def downloadSWPAccessReceivedReportForUser(self,userAlias):
        return self.__downloadReportAndLoadInMemory(userAlias,rptType = "swift-profile-grants-received")

    def downloadDataConsumptionForUser(self,userAlias):
        return self.__downloadReportAndLoadInMemory(userAlias,rptType = "consumption")
    
    def downloadMissingRolesForUser(self,userAlias):
        return  self.__downloadReportAndLoadInMemory(userAlias,rptType = "missing-roles")

    def downloadUserRoleAssignmentForUser(self,userAlias):
       return  self.__downloadReportAndLoadInMemory(userAlias,rptType = "entity-user-roles")

    def downloadDataContributionActivitiesForUser(self,userAlias):
       return self.__downloadReportAndLoadInMemory(userAlias,rptType = "activitylog")
   
    
    def performWorkflowAction(self, action, userAlias, bic,category, comments, checkList=[]):
        logger.info("KYCREST - Start %s ..." % action)
        entityId = self.getEntityId(bic)
        checkListResult = []#self.getCheckListResults(userAlias, category, bic, checkList)
        urltrail = 'resources/v1/entity/%s/folder/%s' % (entityId, action)
        logger.info("KYCREST - URL: %s" % urltrail)
        data = {"categoryCode":category}
        if comments:
            data["comments"] = comments
        if checkListResult:
            data["checkListResult"] = checkListResult
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        res = self.ws.postJson(userEmail,userBic, urltrail, data)
        return res
    
    def getCounterpartyAccess(self,userAlias,bic):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        entityId = self.getEntityId(bic)
        urltrail = 'resources/v1/accessmanagement?grantingEntityId=%s' % entityId
        logger.info("KYCREST - URL GET: %s" % urltrail)
        res = self.ws.getJson(userEmail,userBic, urltrail)
        return res
            
    def getFolderVersion(self,userAlias,bic,category,version):
        logger.info('KYCREST - getFolderVersion')
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        entityId = self.getEntityId(bic)
        folderItemId=self.getFolderItemId(bic, category, version)
        urltrail = 'resources/v1/entity/%s/folder/id/%s' % (str(entityId),str(folderItemId))
        logger.info("KYCREST - URL GET: %s" % urltrail)
        res = self.ws.getJson(userEmail,userBic, urltrail)
        return res
    
    def getFolder(self,userAlias,bic,category):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        entityId = self.getEntityId(bic)
        urltrail = 'resources/v1/entity/%s/folder/%s' % (str(entityId),category) + '?status=LATEST'
        logger.info("URL GET: %s" % urltrail)
        res = self.ws.getJson(userEmail,userBic, urltrail)
        return res
    def editFolder(self,userAlias,bic,category):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        entityId = self.getEntityId(bic)
        urltrail = 'resources/v1/entity/%s/folder/%s' % (str(entityId),category) + '/edit'
        logger.info("KYCREST - URL GET: %s" % urltrail)
        res = self.ws.getJson(userEmail,userBic, urltrail)
        return res
    def getUserProfile(self,userAlias):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        urltrail = 'resources/v1/userprofile'
        logger.info("KYCREST - URL GET: %s" % urltrail)
        res = self.ws.getJson(userEmail,userBic, urltrail)
        return res
    def getFullOMSJson(self,prefix,nbrOfShareholdingCompanies=1,nbrOfShareholders=1,nbrOfKeyControllers=1):
        return json.dumps(KYCData.getFullOMSData(prefix,nbrOfShareholdingCompanies,nbrOfShareholders,nbrOfKeyControllers))

 
    # Data and Docs publishing
    def updateFolder(self,userAlias,bic,category,data,documentsToAdd=[],documentsToRemove=[],documentLinksToAdd=[],documentLinksToRemove=[]):
        (userEmail,userBic) = self.__getUserAndBicFromAlias(userAlias)
        entityId = self.getEntityId(bic)
        dictData = {"categoryCode":category,"data":data,"documentsToAdd":documentsToAdd,"documentsToRemove":documentsToRemove,"documentLinksToAdd":documentLinksToAdd,"documentLinksToRemove":documentLinksToRemove}
        urltrail = 'resources/v1/entity/%s/folder/update' % (str(entityId))
        logger.info("KYCREST - URL POST: %s" % urltrail)
        logger.debug("KYCREST - DATA: %s" % str(dictData))
        res = self.ws.postJson(userEmail,userBic, urltrail,dictData)
        
        return res
    def uploadDocument(self, userAlias, bic, category, doctype, language, extention, docname="", description="", expirationDate=""):
        fold = self.editFolder(userAlias, bic, category )
        newdata = fold.data['data']['data']
        # docDefs = data['category']['documentDefs']
        if not docname:
            docname = "%s_%s.%s" % (doctype, language, extention)
        else:
            docname = "%s.%s" % (docname, extention)
        doc = KYCDocument(self.env.documentPath, docname)
        if not expirationDate:
            doc.expirationDate = "2020-01-01T00:00:00.000Z"
        else:
            doc.expirationDate = expirationDate + "T00:00:00.000Z"
        logger.info("KYCREST - Upload FILE: " + self.env.documentPath + doc.filename)
        doc.documentType = doctype
        doc.documentTypeId = self.getDocumentTypeId(doctype)
        doc.name = docname
        if not description:
            description = "Doc desc for %s-%s-%s-%s" % (category, doctype, language, extention)
        doc.description = description
        doc.content_type = extentionMimeType[extention]
        doc.language = language
        [docid, doctypeid] = self.__uploadFile(userAlias, bic,category, doc)
        folder = self.updateFolder(userAlias, bic, category, newdata,documentsToAdd=[docid])
        return folder
          
if __name__ == '__main__':
    env = KYCENV.KYCEnvironment.getEnvironment('PAC_CI')
    kycrest = KYC(env)
    #res = kycrest.getUserProfile('pac.kyc.submitter1@citi.com')
    #print res.data
    bic8 = 'CITIMYKL'
    office_type = 'HO'
    prefix = office_type + '_' + bic8 + '_'
    cat = 'IOC'
    #reports = ['ARE','OMS','BOD','LEX','LSH','OWS','RES']
    #cat = 'IOC'
    reports = ['EFR'] #,'POR','BAL','COL','COI','STA']
    #reports = ['OWS','ARE','RES']
    #reports = ['CAT','FAT']
    #reports = []
    #bic = 'RBOSAU2SXXX'
    bic = bic8 + 'XXX'
    #bic = 'RBOS_ALL'
    user= 'pac.kyc.submitter1@citi.com'
    #user= 'pac.kyc.submitter1@citi.com'
    #user= 'pac.kyc.qualifier1@swift.com'
    actions=['UPDATE']
    #data = KYCData.getFullOMSData(prefix,1,1,1)
    data = KYCData.getFullIOCData(prefix)
    #data = KYCData.getFullTAXData(prefix)
    #actions=['SUBMIT']
    #actions=['REJECT_QUALIFICATION']
    if 'UPDATE' in actions:
        res = kycrest.updateFolder(user,bic, cat,data )
        print res
        
        for doctype in reports:
            if doctype =='ARE': date = "2017-02-28"
            date = None
            res = kycrest.uploadDocument(user, bic, cat, doctype, 'English', 'pdf', 'document-English', prefix + doctype + '_DOC',date)
            print res
    elif 'SUBMIT' in actions:
        res = kycrest.performWorkflowAction('submit',user,bic, cat,'any comment')
        print res
    elif 'REJECT_QUALIFICATION' in actions:
        res = kycrest.performWorkflowAction('rejectQualification',user,bic, cat,'any comment')
        print res
    
    #print res.data
    #res = kycrest.getUserProfile('pac.kyc.administrator1@bnpparibas.com')
    #print res
    #res = kycrest.rejectAllSWPApprovalTasks('pac.kyc.approver1@swift.com','CITIFIHXXXX')

    #print json.dumps(res.data, sort_keys=True, indent=4, separators=(',', ': '))
    #report = kycrest.downloadSWPAccessGivenReportForUser('pac.kyc.swpgranter1@citi.com')
    #print report
        
    

