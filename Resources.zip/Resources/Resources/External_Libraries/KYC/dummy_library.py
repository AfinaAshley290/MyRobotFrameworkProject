
def ApproveDraft(userEmail, bic, categoryAcronym, comment): pass

def ApproveSWP(userEmail, bic): pass

def DeleteUser(entityGroup, userEmail): pass

def DenyAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, note): pass

def GenerateNewSWP(userEmail, bic): pass

def GrantAccess(userEmail, requestingEntityGroupHead, grantingEntityBic, note): pass

def InviteUser(entityGroup, userEmail, rolesToAssign, entities, entityGroupwideroles): pass

def ProgressWorflowStartedFromBankUpTo(bic, categoryAcronym, finalStatus): pass

def ProgressWorflowStartedFromSWIFTUpTo(bic, categoryAcronym, finalStatus): pass

def ProposeDraftForPublication(userEmail, bic, categoryAcronym, comment, checkList): pass

def ProposeDraftForSubmission(userEmail, bic, categoryAcronym, comment, checkList): pass

def PublishDraft(userEmail, bic, categoryAcronym): pass

def PublishSWP(userEmail, bic, SWPCategoryAcronym): pass

def QualifyDraft(userEmail, bic, categoryAcronym, checkList): pass

def ReconfirmFolder(userEmail, bic, categoryAcronym, comment): pass

def RejectDraftPublication(userEmail, bic, categoryAcronym, comment): pass

def RejectDraftQualification(userEmail, bic, categoryAcronym, comment): pass

def RejectDraftSubmission(userEmail, bic, categoryAcronym, comment): pass

def RequestAccess(userEmail, requestingEntitiesBic, grantingEntityBic, note): pass

def ReserveTask(userEmail, taskType, bic, categoryAcronym): pass

def RevokeAccess(userEmail, revokedEntitiesBic, grantingEntityBic, note): pass

def SendDocumentQuery(userEmail, bic, categoryAcronym, docTypeAcronym, docLanguage, docDescription, docQueryType, requestingBic, note): pass

def SendMessageQuery(userEmail, bic, categoryAcronym, messageTopic, requestingBic, note): pass

def SubmitDraft(userEmail, bic, categoryAcronym, comment, checkList): pass

def SurrenderAccess(userEmail, surrendingEntitiesBic, requestingEntitiesBic, grantingEntityBic, note): pass

def TakeOverTask(userEmail, taskType, bic, categoryAcronym): pass

def UnreserveTask(taskOwnerEmail, taskType, bic, categoryAcronym): pass

def UpdatePreferences(entityGroup, submission4eyes, publicatrion4eyes, freeFormatOutboundCommSupported, takeOverBySwiftSupported): pass

def createDraft(userEmail, bic, categoryAcronym, dataJSON, notApplicableFields): pass

def deleteDocument(userEmail, bic, categoryAcronym, docTypeAcronym, docLanguage, docDescription): pass

def deleteDraft(userEmail, bic, categoryAcronym): pass

def linkDocumentType(userEmail, bic, categoryAcronym, docTypeAcronymTolink): pass

def unlinkDocumentType(userEmail, bic, categoryAcronym, docTypeAcronymToUnlink): pass

def uploadDocument(userEmail, bic, categoryAcronym, docTypeAcronym, language, description, expirationDateString): pass

def uploadDocumentAddAnotherLanguage(userEmail, bic, categoryAcronym, docTypeAcronym, language, originalDocDescription): pass

def uploadDocumentAddEnglishTranslation(userEmail, bic, categoryAcronym, docTypeAcronym, originalDocDescription): pass

