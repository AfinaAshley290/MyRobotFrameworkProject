# -*- coding: utf-8 -*-
import KYCENV
from SdCUtils import LogToStdOut as log
#from SdCSQLUtils import SQLViaCxOracle
from SdCSQLUtils import SQLViaSSH
#from KYC_dao import *
import os
import logging
logger = logging.getLogger("KYCSQL")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)

class KYCSQL():
    # =============================
    # Contructor
    # =============================
    def __init__(self, env=KYCENV.KYCEnvironment.getEnvironment()):
        self.env = env
        self.libDir=os.path.dirname(KYCENV.__file__)
    
    def __runSQL(self,sqlFileName,values=[],returnDict=False):
        sqlFilePath = ""
        if os.sep in sqlFileName:
            splitPath = sqlFileName.split(os.sep)
            sqlFileName=splitPath[-1]
            sqlFilePath=os.sep.join(splitPath[:-1])
        logger.info('KYCSQL - RUN SQL from config file %s/%s with values %s' % (sqlFilePath,sqlFileName, str(values)))
        with SQLViaSSH(self.env.sshDBServerConnectionParams,self.env.dbConnectionParams,sqlFilePath) as sshsql:
        #with SQLViaCxOracle(self.env.dbConnectionParams) as sshsql:
            sshsql.returnDict=returnDict
            logger.info('KYCSQL - print right before runPreparedSQL')
            sqlret = sshsql.runPreparedSQL(sqlFileName, values=values,recreate=False)
        return sqlret
    def getLastFolderStatusAndVersion(self,bic,category):
        ret = self.__runSQL('KYC_Get_Last_Folder_Status_And_Version',[bic,category],returnDict=True)
        if ret:
            return ret[0]
        else:
            return ret
    def runSQL(self,sqlConfigFile, params=[],returnDict=False):
        sqlret = self.__runSQL(sqlConfigFile,params,returnDict)  
        return sqlret
    
          
if __name__ == '__main__':
    env = KYCENV.KYCEnvironment.getEnvironment('PAC_CI')
    kycrpc = KYCSQL(env)
        
    

