import SdCENV
from SdCENV import SIEnvironment, PACEnvironment
from SdCModel import SdCUser
from SdCUtils import LogToStdOut, get_script_dir
import os
class KYCEnvironment(object):
    @classmethod
    def getEnvironment(self,environ=""):
        env = None
        if environ == 'PAC_CI':
            env = KYCPACCIEnvironment()
            os.environ['KYCENV']='CI'
        elif environ == 'PAC':
            env = KYCPACEnvironment()
            os.environ['KYCENV']='PAC'
        else:
            env = KYCPACEnvironment()
            os.environ['KYCENV']='PAC'
        env.defaultHTTPHeader['X-XSRF-TOKEN']='COOKIE:XSRF-TOKEN'
        env.app='kyc'
        env.documentPath = "/".join(get_script_dir().split(os.sep)) + "/KYCDocuments/"
        return env
    
class KYCPACCIEnvironment(SIEnvironment):
    def __init__(self):
        SIEnvironment.__init__(self)
        self.environment = 'CI'
        self.rpcURL= 'https://bekyci02:30163/kyc-xmlrpc/xml-rpc/'
        self.baseURL = 'https://bekyci02:30100/kyc/'
        self.mainURL = 'https://bekyci02:30100/kyc/#'
##        self.loginURL = 'https://www2.int.swift.com/swift/login/dologin#/'
##        self.twoFAURLSetup = 'https://www2.int.swift.com/swift/login/twofa/twoFASetup.faces'
##        self.twoFAURLVerif = 'https://www2.int.swift.com/swift/login/twofa/twoFAVerification.faces'
##        self.doOTPloginURL='https://www2.int.swift.com/swift/login/doOTPlogin?continue=1'
        self.idmURL = 'https://www2.int.swift.com/idm'
        self.sdcURL = 'https://bekyci02:30100/' #'https://www2.int.swift.com/'
        #self.host='bekyci02:30100'
        #self.host='www2.int.swift.com'
        #self.loginHost='www2.int.swift.com'
        self.host=''
        self.loginHost=''
        self.referer='https://bekyci02:30100/kyc/'
        self.password='Abcd1234-'
        self.ldapServer='bedsei20'
        self.ldapPort=20391
        self.ldapPassword='SdC9876-'
        self.sshDBServerConnectionParams={'host':'bekycd20', 
                                              'user':'oracle', 
                                              'password':'pplW,34t',
                                              'keyFile':''}
        
        
        
        self.dbConnectionParams = {'server':'bekycd20','port':3030,'sid':'KYCDB','user':'KYCDB_PAC','password':'pplW,34t','oracle_home':'/opt/oracle/product/12.1.0.2/dbhome_1'}
class KYCPACEnvironment(PACEnvironment):
    def __init__(self):
        PACEnvironment.__init__(self)
        self.environment = 'PAC'
        self.rpcURL= 'https://bekyci02:????/kyc-xmlrpc/xml-rpc/'
        self.baseURL = 'https://kycregistry.test.swift.com/kyc/'
        self.mainURL = 'https://kycregistry.test.swift.com/kyc/#'
        self.loginURL = 'https://login.test.swift.com/swift/login/dologin' #'https://www2.test.swift.com/swift/login/dologin'
        #https://login.test.swift.com/swift/login/login.html
##        self.doOTPloginURL='https://www2.test.swift.com/swift/login/doOTPlogin?continue=1'
##        self.twoFAURLSetup = 'https://www2.test.swift.com/swift/login/twofa/twoFASetup.faces'
##        self.twoFAURLVerif = 'https://www2.test.swift.com/swift/login/twofa/twoFAVerification.faces'
        self.idmURL = 'https://www2.test.swift.com/idm'
        self.sdcURL = 'https://www2.test.swift.com/'
        #self.host='kycregistry.test.swift.com'
        #self.loginHost='kycregistry.test.swift.com'
        #self.host='www2.test.swift.com'
        #self.loginHost='www2.test.swift.com'
        self.host=''
        self.loginHost=''
        self.referer='https://kycregistry.test.swift.com/kyc/'
        self.password='21Holea5!'
        self.ldapServer='bedset20'
        self.ldapPort=20391
        self.ldapPassword='SdC9876-'
        self.sshPath="/".join(get_script_dir().split(os.sep)) + "/ssh/"
        self.sshKeyFile=self.sshPath + 'id_rsa'
        self.sshDBServerConnectionParams={'host':'bekyct20.swift.corp', 
                                              'user':'nagios', 
                                              'password':'',
                                              'keyFile':self.sshKeyFile}
        self.dbConnectionParams = {'server':'bekyct20','port':3030,'sid':'KYCDB','user':'OWNER_KYC','password':'OWNER_KYC','oracle_home':'/opt/oracle/product/12.1.0.2/dbhome_1'}
        #self.dbConnectionParams = {'server':'bekyct20','port':3030,'sid':'KYCDB','user':'OWNER_KYC','password':'OWNER_KYC','oracle_home':'/opt/oracle/product/12.1.0'}

