import random

def getFullOMSData(prefix,nbrOfShareholdingCompanies=1,nbrOfShareholders=1,nbrOfKeyControllers=1):
    STOCK_EXCHANGES = ['ABORO_STOCK_EXCHANGE','ABU_DHABI_SECURITIES_MARKET','AFGHANISTAN_STOCK_EXCHANGE','AGRICULTURAL_FUTURES_EXCHANGE_OF_THAILAND','ALPHA','AMMAN_STOCK_EXCHANGE','AMSTERDAM_STOCK_EXCHANGE','ARTIFICIAL_STOCK_MARKET','ASIA_PACIFIC_STOCK_EXCHANGE','ATHENS_STOCK_EXCHANGE_GENERAL','AUSTRALIAN_SECURITIES_EXCHANGE','BAHAMAS_INTERNATIONAL_SECURITIES_EXCHANGE','BAHIA_SERGIPE_ALAGOAS_STOCK_EXCHANGE','BAHRAIN_BOURSE','BAKU_STOCK_EXCHANGE','BANGALORE_STOCK_EXCHANGE','BANJA_LUKA_STOCK_EXCHANGE','BARBADOS_STOCK_EXCHANGE','BATS_EXCHANGE','BEIRUT_STOCK_EXCHANGE','BELGRADE_STOCK_EXCHANGE','BERMUDA_STOCK_EXCHANGE','BERN_EXCHANGE','BHUBANESWAR_STOCK_EXCHANGE','BM_AND_FBOVESPA','BOLSA_BOLIVIANA_DE_VALORES','BOLSA_CENTROAMERICANA_DE_VALORES','BOLSA_DE_BARCELONA','BOLSA_DE_BILBAO','BOLSA_DE_COMERCIO_DE_BUENOS_AIRES','BOLSA_DE_COMERCIO_DE_CORDOBA','BOLSA_DE_COMERCIO_DE_ROSARIO','BOLSA_DE_LISBOA','BOLSA_DE_MADRID','BOLSA_DE_VALENCIA','BOLSA_DE_VALORES_DE_CABO_VERDE','BOLSA_DE_VALORES_DE_CARACAS','BOLSA_DE_VALORES_DE_COLOMBIA_COLOMBIA_STOCK_EXCHANGE','BOLSA_DE_VALORES_DE_EL_SALVADOR','BOLSA_DE_VALORES_DE_GUAYAQUIL','BOLSA_DE_VALORES_DE_LA_REPUBLICA_DOMINICANA','BOLSA_DE_VALORES_DE_LIMA','BOLSA_DE_VALORES_DE_MOZAMBIQUE','BOLSA_DE_VALORES_DE_MONTEVIDEO','BOLSA_DE_VALORES_DE_NICARAGUA','BOLSA_DE_VALORES_DE_PANAMA','BOLSA_DE_VALORES_DE_QUITO','BOLSA_DE_VALORES_NACIONAL_SA','BOLSA_DE_VALORES_Y_PRODUCTOS_DE_ASUNCION','BOLSA_ELECTRONICA_DE_CHILE','BOLSA_ELECTRONICA_DE_VALORES_DE_URUGUAY','BOLSA_MEXICANA_DE_VALORES','BOLSA_NACIONAL_DE_VALORES_DE_COSTA_RICA','BOMBAY_STOCK_EXCHANGE','BORSA_ISTANBUL','BORSA_ITALIANA','BORSE_BERLIN','BORSE_DSSELDORF','BORSE_FRANKFURT','BORSE_MUNCHEN','BORSE_STUTTGART','BORSEN_HAMBURG_UND_HANNOVER','BOTSWANA_STOCK_EXCHANGE','BOURSE_DE_BRUXELLES','BOURSE_DE_PARIS','BOURSE_DE_TUNIS','BRATISLAVA_STOCK_EXCHANGE','BUCHAREST_STOCK_EXCHANGE','BUDAPEST_STOCK_EXCHANGE','BULGARIAN_STOCK_EXCHANGE','BURSA_MALAYSIA','C2_OPTIONS_EXCHANGE','CALCUTTA_STOCK_EXCHANGE','CAMBODIA_SECURITIES_EXCHANGE','CANADIAN_SECURITIES_EXCHANGE','CASABLANCA_STOCK_EXCHANGE','CAYMAN_ISLANDS_STOCK_EXCHANGE','CBOE_FUTURES_EXCHANGE','CEE_STOCK_EXCHANGE_GROUP','CHANNEL_ISLANDS_STOCK_EXCHANGE','CHICAGO_BOARD_OPTIONS_EXCHANGE','CHICAGO_MERCANTILE_EXCHANGE','CHICAGO_STOCK_EXCHANGE__CHICAGO','CHITTAGONG_STOCK_EXCHANGE','CHI_X_AUSTRALIA','CHI_X_CANADA','COCHIN_STOCK_EXCHANGE','COIMBATORE_STOCK_EXCHANGE','COLOMBO_STOCK_EXCHANGE','CYPRUS_STOCK_EXCHANGE','CZECH_STOCK_EXCHANGE','DAMASCUS_SECURITIES_EXCHANGE','DAR_ES_SALAAM_STOCK_EXCHANGE','DELHI_STOCK_EXCHANGE_DSE','DHAKA_STOCK_EXCHANGE','DIRECTEDGE_EXCHANGE','DOUALA_STOCK_EXCHANGE','DUBAI_FINANCIAL_MARKET','DUBAI_GOLD_AND_COMMODITIES_EXCHANGE','DUTCH_CARIBBEAN_SECURITIES_EXCHANGE','EASTERN_CARIBBEAN_SECURITIES_EXCHANGE','EGYPTIAN_EXCHANGE','ERBIL_STOCK_EXCHANGE','EURONEXT','FAROESE_SECURITIES_MARKET_IN_COOPERATION_WITH_ICELAND_STOCK_EXCHANGE','FUKUOKA_STOCK_EXCHANGE','GEORGIAN_STOCK_EXCHANGE','GHANA_STOCK_EXCHANGE','GRETAI_SECURITIES_MARKET','GUWAHATI_STOCK_EXCHANGE_LTD','GUYANA_STOCK_EXCHANGE','GXG_MARKETS','HANOI_STOCK_EXCHANGE','HOCHIMINH_STOCK_EXCHANGE','HONG_KONG_STOCK_EXCHANGE','HYDERABAD_STOCK_EXCHANGE','INDIAN_COMMODITY_EXCHANGE','INDIAN_NATIONAL_MULTICOMMODITY_EXCHANGE','INDONESIA_STOCK_EXCHANGE','INTERCONNECTED_STOCK_EXCHANGE_OF_INDIA','INTERNATIONAL_SECURITIES_EXCHANGE','IRAN_FARA_BOURSE','IRAN_MERCANTILE_EXCHANGE','IRAQ_STOCK_EXCHANGE','IRISH_STOCK_EXCHANGE','ISLAMABAD_STOCK_EXCHANGE','JAIPUR_STOCK_EXCHANGE_LIMITED','JAMAICA_STOCK_EXCHANGE','JOHANNESBURG_STOCK_EXCHANGE','KARACHI_STOCK_EXCHANGE','KAZAKHSTAN_STOCK_EXCHANGE','KHANAM_STOCK_EXCHANGE_LTD','KHARTOUM_STOCK_EXCHANGE','KOREA_EXCHANGE','KUWAIT_STOCK_EXCHANGE','KYRGYZ_STOCK_EXCHANGE','LAHORE_STOCK_EXCHANGE','LAO_SECURITIES_EXCHANGE','LIBYAN_STOCK_MARKET','LJUBLJANA_STOCK_EXCHANGE','LONDON_STOCK_EXCHANGE','LUDHIANA_STOCK_EXCHANGE_ASSOCIATION_LTD','LUSAKA_STOCK_EXCHANGE','LUXEMBOURG_STOCK_EXCHANGE','MACEDONIAN_STOCK_EXCHANGE','MADHYA_PRADESH_STOCK_EXCHANGE','MADRAS_STOCK_EXCHANGE','MAGADH_STOCK_EXCHANGE_ASSOCIATION','MALAWI_STOCK_EXCHANGE','MALDIVES_STOCK_EXCHANGE','MALTA_STOCK_EXCHANGE','MANGALORE_STOCK_EXCHANGE_LTD','MANILA_COMMODITY_EXCHANGE','MARKET_FOR_ALTERNATIVE_INVESTMENT','MEERUT_STOCK_EXCHANGE_LTD','MERCADO_ABIERTO_ELECTRONICO','MINAS_BRAISLIA_AND_ESPIRITO_SANTO_STOCK_EXCHANGE','MOLDOVA_STOCK_EXCHANGE','MONGOLIAN_STOCK_EXCHANGE','MONTENEGRO_STOCK_EXCHANGE','MONTREAL_EXCHANGE','MOSCOW_EXCHANGE','MULTI_COMMODITY_EXCHANGE','MUSCAT_SECURITIES_MARKET','MYANMAR_SECURITIES_EXCHANGE_CENTRE','NAIROBI_SECURITIES_EXCHANGE','NAMIBIAN_STOCK_EXCHANGE','NASDAQ_CANADA','NASDAQ_DUBAI','NASDAQ_OMX','NASDAQ_OMX_ARMENIA','NASDAQ_OMX_BALTIC','NASDAQ_OMX_EUROPE','NASDAQ_OMX_NORDIC','NATIONAL_COMMODITY_AND_DERIVATIVES_EXCHANGE_LTD','NATIONAL_STOCK_EXCHANGE','NATIONAL_STOCK_EXCHANGE_OF_AUSTRALIA','NATIONAL_STOCK_EXCHANGE_OF_INDIA','NEPAL_STOCK_EXCHANGE','NEW_YORK_STOCK_EXCHANGE','NEW_ZEALAND_EXCHANGE','NEWCONNECT','NIGERIAN_STOCK_EXCHANGE','NORDIC_GROWTH_MARKET','OMEGA_ATS','ONE_CHICAGO','OPEX','OSAKA_SECURITIES_EXCHANGE','OSLO_BORS','OVER_THE_COUNTER_EXCHANGE_OF_INDIA','PALESTINE_EXCHANGE','PFTS_UKRAINE_STOCK_EXCHANGE','PHILIPPINE_DEALING_EXCHANGE','PHILIPPINE_STOCK_EXCHANGE','PRAGUE_STOCK_EXCHANGE','PUNE_STOCK_EXCHANGE_LTD','QATAR_EXCHANGE','REPUBLICAN_STOCK_EXCHANGE_TOSHKENT','RIO_DE_JANEIRO_STOCK_EXCHANGE','ROYAL_SECURITIES_EXCHANGE_OF_BHUTAN','RWANDA_STOCK_EXCHANGE','SAINT_PETERSBURG_EXCHANGE','SANTIAGO_STOCK_EXCHANGE','SAPPORO_SECURITIES_EXCHANGE','SARAJEVO_STOCK_EXCHANGE','SAURASHTRA_KUTCH_STOCK_EXCHANGE_LTD','SHANGHAI_STOCK_EXCHANGE','SHENZHEN_STOCK_EXCHANGE','SIBEX_SIBIU_STOCK_EXCHANGE','SINGAPORE_EXCHANGE_LIMITED','SINGAPORE_MERCANTILE_EXCHANGE','SIX_SWISS_EXCHANGE','SOMALIA_STOCK_EXCHANGE','SOUTH_PACIFIC_STOCK_EXCHANGE','STOCK_EXCHANGE_OF_MAURITIUS','STOCK_EXCHANGE_OF_THAILAND','SWAZILAND_STOCK_EXCHANGE','TADAWUL','TAIWAN_STOCK_EXCHANGE','TEHRAN_STOCK_EXCHANGE','TEL_AVIV_STOCK_EXCHANGE','THAILAND_FUTURES_EXCHANGE','TIRANA_STOCK_EXCHANGE','TOKYO_STOCK_EXCHANGE','TORONTO_STOCK_EXCHANGE','TRINIDAD_AND_TOBAGO_STOCK_EXCHANGE','UGANDA_SECURITIES_EXCHANGE','UKRAINIAN_EXCHANGE','UNITED_STOCK_EXCHANGE','UTTAR_PRADESH_STOCK_EXCHANGE','UZBEKISTAN_STOCK_EXCHANGE','VAJIM_STOCK_EXCHANGE','VALPARAISO_STOCK_EXCHANGE','WARSAW_STOCK_EXCHANGE','WIENER_BORSE','ZAGREB_STOCK_EXCHANGE']
    COUNTRIES=['AD','AF','DZ','AG','AI','AL','AM','AN','AO','AR','AS','AT','AU','AW','AX','AZ','BA','BB','BD','BE','BH','BG','BJ','BW','BF','BL','BM','BN','BO','BQ','BR','BS','BT','BI','BY','BZ','CA','CM','CV','CF','CH','TD','CK','CL','KM','CN','CO','CR','CU','CG','CW','CY','CZ','DE','CI','DK','DM','DO','DJ','EC','EE','EG','GQ','ES','ET','FI','FJ','FK','FM','FO','FR','GA','GB','GD','GE','GF','GG','GM','GI','GL','GH','GN','GP','GW','GR','GT','GU','IR','GY','HK','HN','HR','HT','HU','ID','IE','IQ','IM','IN','IL','JO','IS','IT','JE','JM','KE','JP','KW','KG','KH','KI','LB','KN','KP','KR','LS','KY','KZ','LA','LR','LC','LI','LK','LY','MG','LT','LU','LV','MW','ML','MC','MD','ME','MF','MR','MH','MK','MU','MM','MN','MO','MP','MQ','YT','MS','MT','MA','MV','MZ','MX','MY','NA','NE','NC','NG','NF','OM','NI','NL','NO','NP','NR','NU','NZ','PK','PA','PE','PF','PG','PH','PS','PL','PM','PR','QA','PT','PW','PY','CD','RE','RO','RS','RU','RW','ST','SB','SA','SN','SE','SG','SI','SK','SC','SM','SL','SO','SR','ZA','SS','SV','SD','SZ','SX','TC','SY','TZ','TH','TJ','TL','TM','ER','TO','TG','TT','TV','TW','TN','UA','TR','US','UY','UZ','VA','VC','VE','VG','VI','VN','VU','WF','WS','XK','UG','AE','YE','ZM','ZW']
    GENDER=['Male','Female']
    LEVEL_OF_OWNERSHIP=['DIRECT','INDIRECT']
    KEY_CONTROLLERS=['BOARD_OF_DIRECTORS','EXECUTIVE_MANAGEMENT','SUPERVISORY_BOARD']
    JOB_TITLE=['CHAIRMAN','VICE_CHAIRMAN','DEPUTY','VICE_DEPUTY','CHIEF_EXECUTIVE_OFFICER','CHIEF_PROCUREMENT_OFFICER','CHIEF_OPERATIONS_OFFICER','CHIEF_INFORMATION_OFFICER','CHIEF_TECHNOLOGY_OFFICER','CHIEF_REVENUE_OFFICER','CHIEF_RISK_OFFICER','CHIEF_VISIONARY_OFFICER','DIRECTOR','CHAIRMAN_OF_THE_BOARD','DEPUTY_CHAIRMAN_OF_THE_BOARD','CHAIR_OF_SUPERVISORY_BOARD','CHAIR_OF_AUDIT_COMMITTEE','CHAIR_OF_REMUNERATION_COMMITTEE','CHAIR_OF_SHARIAH_COMPLIANCE_BOARD','CHAIR_OF_RISK_COMMITTEE','MANAGING_PARTNER','POWER_OF_ATTORNEY','NOMINEE']

    data={
              "form-of-organisation":{
                                      "compoundContent":{},
                                      "multiContent":[{"value":"PRIVATE"},{"value":"STATE_OWNED"},{"value":"PUBLIC"}], #
                                      "notApplicable":False,"notDisclosed":False
                                      },
              "s-stock-exchange-name": {"value":"ALPHA", "notApplicable":False},
              "list-percentage": {"value":28, "notApplicable":False}, 
              "stock-exchange-name": {"value":"ABU_DHABI_SECURITIES_MARKET", "notApplicable":False}, 
              "s-stock-exchange-website": {"value":prefix + "second_stock_exch_website.it", "notApplicable":False}, 
              "bearer-shares-possible": {"value":True, "notApplicable":False},
              "stock-exchange-country": {"value":"AF", "notApplicable":False},
              "bearer-shares-percentage": {"value":51, "notApplicable":False},
              "bearer-shares-issued": {"value":True,"notApplicable":False},
              "shareholding-company":{
                                      "multiContent":[]
                                      },
              "shareholder": {
                                      "multiContent":[]
                              },
              "key-controller":{
                                      "multiContent":[]
                                },
              "ho-auditor": {"multiContent":[{"value":"PWC"},{"value":"KPMG"},{"value":"OTHER"}]},
              "s-stock-exchange-country": {"value":"AU"}, 
              "s-stock-exchange-code": {"value":prefix + "second_stock_exch_code_05"}, 
              "ubo-statement": {"value":"UBO_AS_FOLLOWS"}, 
              "stock-exchange-code": {"value":prefix + "stock_exch_code_28"}, 
              "ho-auditor-which-other": {"value":prefix + "Auditor_Other"}, 
              "stock-exchange-website": {"value":prefix + "stock_exch_website.it"}, 
              "auditor": {"compoundContent":{},"multiContent":[{"value":"DELOITTE"},{"value":"ERNST_YOUNG"}],"notApplicable":False,"notDisclosed":False},
              }
    for i in xrange(nbrOfShareholdingCompanies):
        prefixIndexed=prefix + str(i+1)
        shareholdingCompany={"compoundContent":{
                                                 "comp-level-of-ownership": {"value":LEVEL_OF_OWNERSHIP[random.randint(0,1)]},
                                                  "stock-exchange": {"value":STOCK_EXCHANGES[i]},  
                                                 "operating-country": {"value":COUNTRIES[random.randint(0,230)]},
                                                 "shares-percentage": {"value":5+i}, 
                                                 "company-legal-name": {"value":prefixIndexed + "Cpny_Legal_Name"}, 
                                                 "registered-country": {"value":COUNTRIES[random.randint(0,230)]}
                                                 }
                            }
        data['shareholding-company']['multiContent'].append(shareholdingCompany)
    for i in xrange(nbrOfShareholders):
        prefixIndexed=prefix + str(i+1)
        shareholder = {"compoundContent":{
                                          "name": {
                                                   "compoundContent":{
                                                                      "firstname": {"value":prefixIndexed + "UBO_FN_Latin"}, 
                                                                      "middlename": {"value":prefixIndexed + "UBO_MN_Latin"}, 
                                                                      "lastname": {"value":prefixIndexed + "UBO_LN_Latin"}, 
                                                                      "middlename-local": {"value":prefixIndexed + "UBO_MN_Local"}, 
                                                                      "lastname-local": {"value":prefixIndexed + "UBO_LN_Local"}, 
                                                                      "firstname-local": {"value":prefixIndexed + "UBO_FN_Local"}
                                                                      },
                                                   }, 
                                                   "gender": {"value":GENDER[random.randint(0,1)]}, 
                                                   "date-of-birth": {"value":"202"+str((i+1)%10)+"-05-"+str(i%2)+""+str(i%10)+"T00:00:00.000Z"}, 
                                                   "ubo-level-of-ownership": {"value":LEVEL_OF_OWNERSHIP[random.randint(0,1)]}, 
                                                   "nationality": {"multiContent":[{"value":COUNTRIES[random.randint(0,230)]},{"value":COUNTRIES[random.randint(0,230)]}]}, 
                                                   "country-of-birth": {"value":COUNTRIES[random.randint(0,230)]}, 
                                                   "place-of-birth": {"value":prefixIndexed + "UBO_Place-Of_Birth"}, 
                                                   "job-title": {"value":prefixIndexed + "UBO_Job_Title"}, 
                                                   "shares-percentage": {"value":24 + i}, 
                                                   "address-of-residence": {
                                                                            "compoundContent":{
                                                                                               "city": {"value":prefixIndexed + "UBO_City"}, 
                                                                                               "pobox": {"value":prefixIndexed + "UBO_PO_Box"}, 
                                                                                               "street-address": {"value":prefixIndexed + "UBO_Street_Address"}, 
                                                                                               "country": {"value":COUNTRIES[i+5]}}
                                                                            },
													},
										}
        data['shareholder']['multiContent'].append(shareholder)
    for i in xrange(nbrOfKeyControllers):
        prefixIndexed=prefix + str(i+1)
        keyController = {"compoundContent":{
                                                                      "name": {
                                                                               "compoundContent":{
                                                                                                  "firstname": {"value":prefixIndexed + "KCTR_FN_Latin"}, 
                                                                                                  "middlename": {"value":prefixIndexed + "KCTR_MN_Latin"}, 
                                                                                                  "lastname": {"value":prefixIndexed + "KCTR_LN_Latin"}, 
                                                                                                  "middlename-local": {"value":prefixIndexed + "KCTR_MN_Local"}, 
                                                                                                  "lastname-local": {"value":prefixIndexed + "KCTR_LN_Local"}, 
                                                                                                  "firstname-local": {"value":prefixIndexed + "KCTR_FN_Local"}
                                                                                                  }
                                                                               },
                                                                      "gender": {"value":GENDER[random.randint(0,1)]}, 
                                                                      "date-of-birth": {"value":"203"+str((i+1)%10)+"-04-2"+str((i+1)%10)+"T00:00:00.000Z"}, 
                                                                      "place-of-birth": {"value":prefixIndexed + "KCTR_Place-Of_Birth"},
                                                                      "appointment-date": {"value":"200"+str((i+1)%10)+"-05-"+str((i+10)%28)+"T00:00:00.000Z"}, 
                                                                      "member-of": {
                                                                                    "compoundContent":{
                                                                                                       "membership": {"multiContent":[{"value":KEY_CONTROLLERS[random.randint(0,2)]},{"value":"OTHER"}]},
                                                                                                       "membership-which-other": {"value":prefixIndexed +"KCTR_Membership_other"}
                                                                                                       },
                                                                                    }, 
                                                                      "nationality":  {"multiContent":[{"value":COUNTRIES[i+8]},{"value":COUNTRIES[random.randint(0,230)]}]},
                                                                      "country-of-birth":{"value":COUNTRIES[random.randint(0,230)]}, 
                                                                      "job-title":{"multiContent":[{"value":JOB_TITLE[random.randint(0,22)]},{"value":JOB_TITLE[random.randint(0,22)]}]},
                                                                      "address-of-residence": {
                                                                                               "compoundContent":{
                                                                                                                  "city": {"value":prefixIndexed + "KCTR_City"}, 
                                                                                                                  "pobox": {"value":prefixIndexed + "KCTR_PO_Box"}, 
                                                                                                                  "street-address": {"value":prefixIndexed + "KCTR_Street_Address"}, 
                                                                                                                  "country":{"value":COUNTRIES[random.randint(0,230)]}}
                                                                                               },
                                                                      }
                                                   }
        data['key-controller']['multiContent'].append(keyController)
        print data
    return data


def getFullOMSDataPR2_1(prefix,nbrOfShareholdingCompanies=1,nbrOfShareholders=1,nbrOfKeyControllers=1):
    data={
              "form-of-organisation":"PRIVATE,PUBLIC,STATE_OWNED",
              "s-stock-exchange-name": "ALPHA",
              "list-percentage": 28, 
              "stock-exchange-name": "ABU_DHABI_SECURITIES_MARKET", 
              "s-stock-exchange-website": prefix + "second_stock_exch_website.it", 
              "bearer-shares-possible": True,
              "stock-exchange-country": "AF",
              "bearer-shares-percentage": 51,
              "bearer-shares-issued": True,
              "shareholding-company":[],
              "shareholder": [],
              "key-controller":[],
              "ho-auditor": "PWC,KPMG,OTHER",
              "s-stock-exchange-country": "AU", 
              "s-stock-exchange-code": prefix + "second_stock_exch_code_05", 
              "ubo-statement": "UBO_AS_FOLLOWS", 
              "stock-exchange-code": prefix + "stock_exch_code_28", 
              "ho-auditor-which-other": prefix + "Auditor_Other", 
              "stock-exchange-website": prefix + "stock_exch_website.it", 
              "auditor": "DELOITTE,ERNST_YOUNG",
              }
    for i in xrange(nbrOfShareholdingCompanies):
        prefixIndexed=prefix + str(i+1)
        shareholdingCompany={"comp-level-of-ownership":"DIRECT", 
                             "stock-exchange": "TEL_AVIV_STOCK_EXCHANGE", 
                             "operating-country": "BE",
                             "shares-percentage": 25+i, 
                             "company-legal-name":prefixIndexed + "Cpny_Legal_Name", 
                             "registered-country": "BE"
                            }
        data['shareholding-company'].append(shareholdingCompany)
    for i in xrange(nbrOfShareholders):
        prefixIndexed=prefix + str(i+1)
        shareholder = {"name": {
                                "firstname": prefixIndexed + "UBO_FN_Latin",
                                "middlename": prefixIndexed + "UBO_MN_Latin",
                                "lastname":prefixIndexed + "UBO_LN_Latin",
                                "middlename-local": prefixIndexed + "UBO_MN_Local",
                                "lastname-local": prefixIndexed + "UBO_LN_Local",
                                "firstname-local": prefixIndexed + "UBO_FN_Local"}, 
                        "gender":"Male", 
                        "date-of-birth": "2024-05-10T00:00:00.000Z", 
                        "ubo-level-of-ownership": "DIRECT", 
                        "nationality": "SN,SE", 
                        "country-of-birth": "AN", 
                        "job-title": prefixIndexed + "UBO_Job_Title", 
                        "shares-percentage": 24 + i, 
                        "address-of-residence": {"city": "UBO_City",
                                                 "pobox": prefixIndexed + "UBO_PO_Box", 
                                                 "street-address": prefixIndexed + "UBO_Street_Address", 
                                                 "country": "BE"},
                       }
        data['shareholder'].append(shareholder)
    for i in xrange(nbrOfKeyControllers):
        prefixIndexed=prefix + str(i+1)
        keyController = {"name":{
                                 "firstname":prefixIndexed + "KCTR_FN_Latin",
                                 "middlename": prefixIndexed + "KCTR_MN_Latin", 
                                 "lastname": prefixIndexed + "KCTR_LN_Latin", 
                                 "middlename-local": prefixIndexed + "KCTR_MN_Local",
                                 "lastname-local": prefixIndexed + "KCTR_LN_Local",
                                 "firstname-local":prefixIndexed + "KCTR_FN_Local"
                                 },
                         "gender": "Male", 
                       "date-of-birth":"2020-04-30T00:00:00.000Z", 
                       "appointment-date": "2013-05-16T00:00:00.000Z", 
                       "member-of": {"membership": "BOARD_OF_DIRECTORS,EXECUTIVE_MANAGEMENT,OTHER",
                                     "membership-which-other": prefixIndexed +"KCTR_Membership_other"
                                     }, 
                       "nationality":  "BE,FR",
                       "country-of-birth":"GB",
                       "job-title":"CHAIRMAN,DEPUTY,CHIEF_EXECUTIVE_OFFICER,CHIEF_PROCUREMENT_OFFICER",
                       "address-of-residence": {"city": prefixIndexed + "KCTR_City",
                                                "pobox": prefixIndexed + "KCTR_PO_Box",
                                                "street-address":prefixIndexed + "KCTR_Street_Address",
                                                "country":"BE"},
                       }
        data['key-controller'].append(keyController)
    return data
def getFullIOCData(prefix):
    data = {"institution-status":{"value":"BANK", "notApplicable":False, "notDisclosed":False},
            "legal-form-anglicised":{"value":"ASSOCIATION"},
            "legal-form-anglicised-which-other":{"value": prefix + "_legalFormAngliOther"},
            "legal-name-local":{"value": prefix + "_legalNameLoc"},
            "trading-name-local":{"value": prefix + "_tradingName"},
            "legal-name-previous":{"value": prefix + "_previous_legal_mame"},
            "legal-name-lastchanged":{"value":"3928"},
            "phone":{"value":"23344565666"},
            "fax":{"value":"223345555777"},
            "website":{"value":"hjggs.com", "notApplicable":False},
            "registration-number":{"value":prefix + "_REGNUM2333"},
            "registration-authority":{"value":"ALABAMA_SECRETARY_OF_STATE"},
            "registration-authority-which-other":{"value":prefix + "_REG_Auth_other"},
            "registration-authority-country":{"value":"AN"},
            "incorporation-date":{"value":"2018-02-02T00:00:00.000Z"},
            "ho-legal-form-anglicised":{"value":"UNLIMITED_COMPANY"},
            "ho-legal-form-anglicised-which-other":{"value":prefix + "_ho_legal_form_other"}, 
            "regulatory-status":{"value":"PARTIAL"},
            "regulatory-status-which-other":{"value":prefix + "_reg_status_other"},
            "regulatory-status-details":{"value":prefix + "_reg_status_details"},
            "regulator":{"value":"ALASKA_DEPARTMENT_OF_COMMERCE_COMMUNITY_AND_ECONOMIC_DEVELOPMENT_BANKING_AND_SECURITIES"},
            "regulator-which-other":{"value":prefix + "_reg_status_details"},
            "regulator-website":{"value":prefix + "_reg_website.com"},
            "regulator-country":{"value":"AF"},
            "second-regulator":{"value":"ALBERTA_SECURITIES_COMMISSION"},
            "second-regulator-which-other":{"value":prefix + "_second_reg_other"},
            "second-regulator-website":{"value":prefix + "_second_reg_website.com"},
            "second-regulator-country":{"value":"AL"},
            "supervising-authority-country":{"value":"FR"},
            "license-type":{"multiContent":[{"value":"FULL"}, {"value":"OFFSHORE"}]},
            "license-number":{"value":prefix + "_licence_number"},
            "license-authority":{"value":prefix + "_auth"},
            "license-authority-country":{"value":"AN"}
    }
    return data
def getFullIOCDataPR2(prefix):
    data={"institution-status":"BANK",
          "legal-form-anglicised":"EUROPEAN_PUBLIC_LIMITED",
          "legal-name-local":prefix + "_legal_name",
          "trading-name-local":prefix + "_trading_name",
          "legal-name-previous":prefix + "_previous_name",
          "legal-name-lastchanged":"2000",
          "phone":"2930409494",
          "fax":"0948483939",
          "website":prefix + "_website.com",
          "registration-number":prefix + "_regnum_1234",
          "registration-authority":"ALASKA_DIVISION_OF_CORPORATIONS_BUSINESS_AND_PROFESSIONAL_LICENSING",
          "registration-authority-country":"AF",
          "incorporation-date":"1988-02-11T00:00:00.000Z",
          "ho-legal-form-anglicised":"CORP_INCORP",
          "regulatory-status":"FULL",
          "regulator":"ALBERTA_OFFICE_OF_THE_SUPERINTENDENT_OF_INSURANCE",
          "regulator-website":prefix + "_prim_financial_reg.com",
          "regulator-country":"AD",
          "second-regulator":"ALBERTA_OFFICE_OF_THE_SUPERINTENDENT_OF_INSURANCE",
          "second-regulator-website":prefix + "_second_financial_reg.com",
          "second-regulator-country":"BN",
          "license-type":"FULL",
          "license-number":prefix + "_licence_num",
          "license-authority":prefix + "_licence_num_autho",
          "license-authority-country":"AI"}
    return data
def getFullTAXData(prefix):
    data = {"fatca-status":{"value":"NON_EXEMPT"},
            "fatca-exempt-status-reason":{},
            "fatca-exempt-status-reason-which-other":{},
            "fatca-in-scope-entities":{"value":"DEEMED_COMPLIANT_FFI"},
            "giin":{"value":"xxx3xx.xx22x.xx.x4x"},
            "specific-fatca-contact":{"value":True},
            "fatca-contact":{"compoundContent":{"firstname":{"value":prefix + "_FATCAContactFirstname"},
                                                "lastname":{"value":prefix + "_FATCAContactLastname"},
                                                "job-title":{"value":prefix + "_FATCAContactJobTitle"},
                                                "phone":{"value":"28938383273"},
                                                "email":{"value":prefix + "_FATCAContactEmail@gmail.com"}}},
            "tax-number":{"value":"284302140832"},
            "tax-country":{"multiContent":[{"value":"DZ"},{"value":"AG"},{"value":"UG"}]},
            "tax-replacement":{},
            "text-field-w-def-value":{"value":"CITIBANK A.S."},
            "number-field-w-def-value":{"value":325401},
            "sub-text-field-w-def-value":{"value":"CITIUS33XXX"},
            "sub-b-text-field-w-def-value":{"value":"CITI_GROUP"},
            "stock":{"multiContent":[{"compoundContent":{"stock-exchanges-country":{"value":"US"},
                                                         "stock-exchange-market":{"value":"NEW_YORK_BOARD_OF_TRADE"},
                                                         "stock-exchange-product":{"multiContent":[{"value":"PRODUCT_US_ONE"},{"value":"PRODUCT_US_TWO"},{"value":"PRODUCT_US_THREE"},{"value":"PRODUCT_US_FOUR"}]
                                                                                   }
                                                         }
                                      }]
                     }
            }
    return data
def getFullTOBData(prefix):
    data = {}
    return data
if __name__=="__main__":
    pass
