import ldap
from SdCModel import SdCIDMUser
import SdCUtils
import re
class Environment(object):
    def __init__(self):
        self.users= {}
        self.environment = 'PAC'
        self.sdcURL = "https://www2.test.swift.com/"
        self.samlURL = self.sdcURL + "saml/SAML_www2_form_external/bcsamlpost"
        self.ldapServer='bedset20'#'bedsei20'
        self.ldapPort=20391
        self.ldapUser='cn=Directory Manager'
        self.ldapPassword='SdC9876-'
        self.password='SdC9876-'
        self.ldapBaseDN="o=swift.com"
        self.profileLoadedFlag = False
        self.host='www2.test.swift.com'
        self.loginHost='www2.test.swift.com'
        self.app='idm'
        self.sshDBServerConnectionParams={}
        self.dbConnectionParams={}
        self.defaultHTTPLoginHeader = {
                    'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Encoding':'gzip, deflate',
                    'Accept-Language':'en-us,en;q=0.5',
                    'Connection':'keep-alive',
                    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'
        }
        self.defaultHTTPHeader = {
                    'Accept':'application/json, text/plain, */*',
                    'Accept-Encoding':'gzip, deflate',
                    'Accept-Language':'en-us,en;q=0.5',
                    'Connection':'keep-alive',
                    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'
        }
    @property
    def url(self):
        return self.baseURL
    @property
    def loginUrl(self):
        return self.loginURL
    @property
    def samlUrl(self):
        return self.samlURL
    @property
    def sdcUrl(self):
        return self.sdcURL
    @property
    def httpHeader(self):
        httpHead =  self.defaultHTTPHeader
        if self.host:
            httpHead['Host']=self.host
        #httpHead['Referer']=self.referer
        httpH = {}
        for k,v in httpHead.items():
            httpH[k] = v
        return httpH
    @property
    def loginHttpHeader(self):
        httpHead =  self.defaultHTTPLoginHeader
        if self.loginHost:
            httpHead['Host']=self.loginHost
        #httpHead['Referer']=self.loginReferer
        return httpHead
    def getIDMUser(self,key):
        if key in self.users.keys():
            return self.users[key]
        else:
            self.users[key] = SdCIDMUser(key,self.password)
            self.loadUserProfileFromLdap()
            return self.users[key]
    def getSdCUser(self,key,bic=""):
        if key in self.users.keys():
            return self.users[key].getSdCUser(bic)
        else:
            self.users[key] = SdCIDMUser(key,self.password)
            self.loadUserProfileFromLdap()
            return self.users[key].getSdCUser(bic)
    def printUsers(self):
        print self.users.keys()
    def addIDMUser(self,user, alias=""):
        if not alias: alias = user.email
        self.users[alias]=user
    def addSdCUser(self,user, alias=""):
        idmUser=SdCIDMUser(user.email,user.password)
        idmUser.firstName = user.firstName
        idmUser.lastName = user.lastName
        if not alias: alias = user.email
        self.users[alias]=idmUser
    def addUser(self,email,password="", alias=""):
        if not password: password = self.password
        if not alias: alias = email
        self.users[alias]=SdCIDMUser(email,password)
    
    @classmethod
    def getEnvironment(self,environ=""):
        if environ=='SI':
            return SIEnvironment()
        elif environ=='PAC':
            return PACEnvironment()
        else:
            return PACEnvironment()
            
    def loadUserProfileFromLdap(self, reloadFlag=False):
        # cleanup users
        emails=[]
        if reloadFlag:
            for key in self.users.keys():
                self.users[key].loadedFromLdap=False
            emails = self.users.keys()
        else:
            for key in self.users.keys():
                if not self.users[key].loadedFromLdap:
                    emails.append(self.users[key].email)
        # load missing users
        idmUsersToAdd = SdCUtils.loadUserProfileFromLdap(emails,self.ldapServer,self.ldapPort,self.ldapUser,self.ldapPassword,self.ldapBaseDN)
        for key in self.users.keys():
            email = self.users[key].email
            if email in idmUsersToAdd.keys():
                idmUsersToAdd[email].password = self.users[key].password
                self.users[key]=idmUsersToAdd[email]
    def getSQLViaSSH(self):
        return SdCUtils.SQLViaSSH(self.sshDBServerConnectionParams,self.dbConnectionParams)
        
class PACEnvironment(Environment):
    def __init__(self):
        Environment.__init__(self)
        self.users= {}
        self.environment = 'PAC'
        self.ldapServer='bedset20'
        self.host='login.test.swift.com'
        self.sdcURL = "https://" + self.host + "/"
        self.loginHost=self.host
        self.loginHost='login.test.swift.com'
        #self.loginHost='www2.test.swift.com'
        self.loginReferer= "https://" + self.loginHost + "/swift/login/dologin#/"
        self.loginURL = "https://" + self.loginHost + "/swift/login/dologin#/"
        self.idmURL = self.sdcURL + 'idm'
        self.twoFAURLSetup = "https://" + self.loginHost + "/swift/login/twofa/twoFASetup.faces"
        self.twoFAURLVerif = "https://" + self.loginHost + "/swift/login/twofa/twoFAVerification.faces"
        self.doOTPloginURL= "https://" + self.loginHost + "/swift/login/doOTPlogin?continue=1"
        self.MAIL_SERVER_IP_ADDRESS = "10.4.128.88"
        self.MAIL_SERVER_USER="mailpac"
        self.MAIL_SERVER_PASSWORD="SdC9876-"
        
        
class SIEnvironment(Environment):
    def __init__(self):
        Environment.__init__(self)
        self.users= {}
        self.environment = 'SI'
        self.ldapServer='bedsei20'
        self.host='www2.int.swift.com'
        self.sdcURL = "https://" + self.host + "/"
        self.loginHost='login.int.swift.com'
        self.loginReferer= "https://" + self.loginHost + "/swift/login/dologin#/"
        self.loginURL = "https://" + self.loginHost + "/swift/login/dologin#/"
        self.idmURL = self.sdcURL + 'idm'
        self.twoFAURLSetup = "https://" + self.loginHost + "/swift/login/twofa/twoFASetup.faces"
        self.twoFAURLVerif = "https://" + self.loginHost + "/swift/login/twofa/twoFAVerification.faces"
        self.doOTPloginURL= "https://" + self.loginHost + "/swift/login/doOTPlogin?continue=1"
        self.MAIL_SERVER_IP_ADDRESS = "10.4.97.83"
        self.MAIL_SERVER_USER="mailsi"
        self.MAIL_SERVER_PASSWORD="mailsi"
if __name__=="__main__":
    env = Environment()
    env.addUser('pac.xavier.platiaux@swift.com', password="", alias='PITOU')
    env.loadUserProfileFromLdap()
    user = env.getSdCUser('PITOU')
    
