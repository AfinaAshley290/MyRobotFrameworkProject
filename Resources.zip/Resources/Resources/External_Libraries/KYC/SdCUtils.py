import ldap
import csv,sqlite3,os 
import logging
from SdCModel import SdCIDMUser
import paramiko,socket, uuid
import sys, json, re
import inspect, pickle
from SdCMail import MailServer
#import cx_Oracle
import traceback

logger = logging.getLogger("SdCUtils")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)


def get_script_dir(follow_symlinks=True):
    if getattr(sys, 'frozen', False): # py2exe, PyInstaller, cx_Freeze
        path = os.path.abspath(sys.executable)
    else:
        path = inspect.getabsfile(get_script_dir)
    if follow_symlinks:
        path = os.path.realpath(path)
    return os.path.dirname(path)


class SdCSSH():
    def __init__(self,conParams):
        self.ssh = None
        self.user = conParams['user']
        self.password = conParams['password']
        self.keyFile=conParams['keyFile']
        self.host=conParams['host']
        self.dryrun=False
    def init(self):
        logger.info('SdCUtils - Opening ssh connection to server %s ...' % self.host)
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            logger.info('SdCUtils - Connecting to server %s as %s ...' % (self.host,self.user))
            if self.keyFile:
                self.ssh.connect(self.host ,10022, username=self.user,key_filename=self.keyFile)
            else:
                self.ssh.connect(self.host ,10022, username=self.user,password=self.password)
            logger.info('SdCUtils - Connected :-)')
        except paramiko.AuthenticationException, e:
            logger.error("SdCUtils - Authentication problem: %s" % str(e))
        except socket.error, e:
            logger.error("SdCUtils - Communication problem: %s" % str(e))
    def release(self):
        logger.info('SdCUtils - Closing connection ...')
        self.ssh.close()
        logger.info('SdCUtils - Connection closed')
    def __enter__(self):
        self.init()
        return self
    def __exit__(self, type, value, traceback):
        self.release()
    def executeCommand(self,command,forceExec=False):
        if not self.dryrun or forceExec:
            logger.info('SdCUtils - Run command: %s' % command)
            stdin, stdout, stderr =  self.ssh.exec_command(command)
            error =  stderr.read()
            if error and not 'No such file or directory' in error: raise Exception(error)
            return stdout
        else:
            logger.info('[Dryrun] command: %s' % command)


def LogToStdOut(fn):
    varList, _, _, default = inspect.getargspec(fn)
    d = {}
    if default is not None:
        d = dict((varList[-len(default):][i], v) for i, v in enumerate(default))
    def f(*argt, **argd):
        logger.debug(('SdCUtils - Enter %s' % fn).center(100, '='))
        d.update(dict((varList[i], v) for i, v in enumerate(argt)))
        d.update(argd)
        for c in d.iteritems():
            logger.debug('%s = %s' % c)
        ret = fn(*argt, **argd)
        logger.debug( 'SdCUtils - return: %s' % str(ret))
        logger.debug( ('SdCUtils - Exit %s' % fn).center(100, '='))
        return ret
    return f
def LogAccess(fn):
    return LogFunctionAccess(fn,logger)
def LogFunctionAccess(fn,logger):
    varList, _, _, default = inspect.getargspec(fn)
    d = {}
    if default is not None:
        d = dict((varList[-len(default):][i], v) for i, v in enumerate(default))
    def f(*argt, **argd):
        logger.debug(('SdCUtils - Enter %s' % fn).center(100, '='))
        d.update(dict((varList[i], v) for i, v in enumerate(argt)))
        d.update(argd)
        for c in d.iteritems():
            logger.debug('%s = %s' % c)
        ret = fn(*argt, **argd)
        logger.debug( 'SdCUtils - return: %s' % str(ret))
        logger.debug( ('SdCUtils - Exit %s' % fn).center(100, '='))
        return ret
    return f
@LogAccess
def loadUserProfileFromLdap(userEmails,server,port,ldapUser,ldapPassword,ldapBaseDN):
    """
    Return a list of SdCIDMUser(s) from LDAP
    """
    sdCIDMUsers={}
    try:
        logger.info("SdCUtils - Connecting to ldap, Server: %s, Port: %s, User: %s" % (server, port,ldapUser))
        l = ldap.open(server, port=port)
        l.protocol_version = ldap.VERSION3
        username = ldapUser
        password = ldapPassword
        l.simple_bind(username, password)
        logger.info( "SdCUtils - Connected :-)")
    except ldap.LDAPError, e:
        logger.error(str(e))
        return False
    baseDN = ldapBaseDN
    searchScope = ldap.SCOPE_SUBTREE
    retrieveAttributes = None
    for email in userEmails:
        logger.info( "SdCUtils - Searching ldap for user %s" % (email))
        user=SdCIDMUser(email)
        searchFilter = "mail="+email+"*"
        ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
        while 1:
            result_type, result_data = l.result(ldap_result_id, 0)
            if not result_data:
                break
            else:
                if result_type == ldap.RES_SEARCH_ENTRY:
                    email = result_data[0][1]['mail'][0]
                    try:
                        SwiftProfileId = result_data[0][1]['swiftProfileId'][0]
                        bic = result_data[0][1]['swiftBicId'][0]
                        user.firstName = result_data[0][1]['givenName'][0]
                        user.lastName = result_data[0][1]['sn'][0]
                        user.setProfileId(bic, SwiftProfileId)
                        user.loadedFromLdap=True
                        logger.info( "SdCUtils - Found user: %s, %s, %s" % (email, bic, SwiftProfileId))
                    except:
                        pass
        sdCIDMUsers[email]=user
    return sdCIDMUsers
@LogAccess
def extractCSVToSqlite3DB(csvPath):
    connection = sqlite3.connect(":memory:")
    tableName = csvPath.split('/')[-1].replace('.csv','').replace('.','_').upper()
    cur = connection.cursor()
#     sqlDrop="DROP TABLE IF EXISTS %s;" % tableName
#     print sqlDrop
#     cur.execute(sqlDrop)
    connection.commit()
    with open(csvPath,'rb') as fin: 
        dr = csv.DictReader(fin) # comma is default delimiter
        columns=[]
        tableColumns=[]
        to_db=[]
        for row in dr:
            if not columns:
                columns = [h for h in row.keys()]
                tableColumns = [col.replace(' ','_')for col in columns]
                sql = "CREATE TABLE %s (%s);" % (tableName,", ".join(tableColumns))
                print sql
                cur.execute(sql)
                to_db.append([str(row[col]) for col in columns])
            else:
                to_db.append([str(row[col]) for col in columns])
        print to_db
        if to_db:
            sqlinsert = "INSERT INTO %s (%s) VALUES (%s);" % (tableName,", ".join(tableColumns),",".join(["?"] * len(columns)))
            print sqlinsert
            cur.executemany(sqlinsert, to_db)
    connection.commit()
    cur.close()
    #os.remove(csvPath)
    return tableName, connection
if __name__=='__main__':
    env = 'PAC'
