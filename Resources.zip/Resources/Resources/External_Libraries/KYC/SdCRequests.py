import requests
from requests.exceptions import *
import json
import itertools
import mimetools
import mimetypes
import traceback
import os,re
from SdCModel import SdCUser
from urllib2 import URLError, HTTPError
from HTMLParser import HTMLParser
import logging
from SdCMail import MailServer

extentionMimeType={'jpg':'image/jpeg',
                   'tiff':'image/tiff',
                   'pdf':'application/pdf',
                   'png':'image/png'}

logger = logging.getLogger("SdCRequests")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)


class HTTPConnection():
    """
    HTTP Connection  object used to store the Requests session along with user details in a connection pool
    """
    def __init__(self,user,session):
        self.email=user.email
        self.bic=user.bic
        self.session=session           

class HTTPRequest(object):
    def __init__(self,environment):
        self.connPool = self.HTTPConnectionPoolMulti()
        self.env=environment 
    class HTTPConnectionPoolMulti():
        """
        Connection pool to store Requests sessions in order to avoid IDM connection
        """
        def __init__(self):
            self.pool={}
            
        def putConnection(self,conn):
            key = conn.email + '@' + conn.bic
            logger.debug("SdCRequests - putConnection - Put back connection in the pool: key = %s" % key)
            if not key in self.pool.items():
                self.pool[key]=[]
            self.pool[key].append(conn)

        def getConnection(self,user):
            logger.debug("SdCRequests - getConnection - Getting connection from the pool for %s" % str(user))
            key = user.email + '@' + user.bic
            if key in self.pool.keys() and self.pool[key]:
                conn = self.pool[key].pop()
                return conn
            else:
                return None  

    def __getConnection(self,user,headers):
        # -- get a connection from the pool, if no connection for the given , will do the login
        conn = self.connPool.getConnection(user)
        if not conn:
            self.login(user)
            conn = self.connPool.getConnection(user)
        session = conn.session
        http_header = {}
        logger.debug([(k,v) for k,v in headers.items()])
        logger.debug([(k,v) for k,v in session.cookies.items()])
        # -- loop on the header and if the key contains 'COOKIE:', will replace the value with the value from the corresponding cookie
        for k,v in headers.items():
            if 'COOKIE:' in str(v): # value from cookies
                cookieName = v.split(':')[1]
                for k2,v2 in session.cookies.items():
                    if k2 == cookieName:
                        http_header[k]=v2  
                        logger.info( "SdCRequests - getConnection - cookie value %s:%s - added to header %s" % (k2,v2,k))
                        break
              
            else:
                http_header[k]=v
        session.headers=http_header
        logger.debug([(k,v) for k,v in session.headers.items()])
        return conn

    def post(self,user,url,data={},headers={}):
        """
        Retrieve a connection from the pool, do the HTTP POST using the corresponding Requests session and put back the connection in the pool
        """
        logger.debug("SdCRequests - post - DATA: %s" % str(data)[:2000])
        conn=self.__getConnection(user,headers)
        session = conn.session
        logger.info( 'SdCRequests - post - URL (POST): ' + url)
        logger.debug( 'SdCRequests - post - Request HTTP Headers: ' + str(session.headers))
        res = None
        try:
            result = session.post(url, data)
            res = HTTPCallResult(result)
        except HTTPError, e:
            logger.error("SdCRequests - post - HTTP error: %s" % str( e.response.code))
            res = HTTPCallResult(e.response)
       
        res.requestUrl=url
        res.requestType='POST'
        res.requestData=data
        res.headers=session.headers
        self.connPool.putConnection(conn)
        return res
   
    def __handleSAMLResponse(self,res,session):
        """
        A SAML Authnrequest is build and send to the IdP (Identidy Provider). 
        IdP will present the user with a login form in which they can enter their username and password. 
        Once the user has logged in, the IdP generates a SAML token that includes identity information about the user.
        SAML Response requires the user to press a button to post the SAML token. 
        Normally the page is designed to do it via Javascript but we are not using a browser so we need to do the POST ourself.
        That is precisely what that code is doing.
        """
        
        text=res.text.replace('\n','')
        logger.debug('SdCRequests - __handleSAMLResponse - HTML: %s' % text)
        m = re.match('^.*<form action="(.*?)".*$', text)
        if m:
            logger.info("SdCRequests - __handleSAMLResponse - Handle SAML Token form posting")
            SALMURL = m.group(1)
            SALMURL = HTMLParser().unescape(SALMURL)
            
            m = re.match('^.*<input *type="hidden" *name="RelayState" *value="(.*?)"/>.*<input *type="hidden" *name="SAMLResponse" *value="(.*?)"/>.*$',text)
            if m:
                params = {
                      'RelayState':m.group(1),
                      'SAMLResponse':m.group(2)
                }     
                logger.info("SdCRequests - __handleSAMLResponse - SAML URL: %s; RelayState:%s , SAMLResponse: %s"  % (SALMURL,m.group(1),m.group(2)))   
                res  = session.post(SALMURL,params)
                logger.info('SdCRequests - __handleSAMLResponse - PAGE TITLE: %s' % self.__getPageTitle(res.text))
                logger.debug( res.text.replace('\n',''))
        return res

    def get(self,user,url,headers={}):
        """
        Retrieve a connection from the pool, do the HTTP GET using the corresponding Requests session and put back the connection in the pool
        """
        conn=self.__getConnection(user,headers)
        session = conn.session
        logger.info('SdCRequests - get - URL (GET): ' + url)
        logger.debug('SdCRequests - get - Request HTTP Headers: ' + str(session.headers))
        res = None
      
        try:
            result = session.get(url)
            logger.debug([(k,v) for k,v in session.headers.items()])
            logger.debug([(k,v) for k,v in session.cookies.items()])
            text = result.text.replace('\n','')
            logger.info('SdCRequests - get - PAGE TITLE: %s' % self.__getPageTitle(result.text))
            res = self.__handleSAMLResponse(result,session)
            res = HTTPCallResult(result)
        except HTTPError, e:
            logger.error("SdCRequests - get - HTTP error: %s" % str( e.response.code))
            res = HTTPCallResult(e.response)
            
        res.requestUrl=url
        res.requestType='GET'
        res.requestData=[]
        res.headers=session.headers
        self.connPool.putConnection(conn)
        return res

    def downloadFile(self,user,url,dir,headers={}):
        """
        Retrieve a connection from the pool, do the HTTP GET to download a file in the given directory using the corresponding Requests session and put back the connection in the pool
        """
        conn=self.__getConnection(user,headers)
        session = conn.session
        res = None
        response = None
        filename='unknown'
        logger.info('SdCRequests - downloadFile - DOWNLOAD FILE in directory %s' % dir)
        logger.info('SdCRequests - downloadFile - URL (GET): ' + url)
        try:
            logger.info('SdCRequests - before get')
            response = session.get(url,stream=True)
            logger.info('SdCRequests - after get')
            res = HTTPCallResult(response)
            logger.info('SdCRequests - after HTTPCallResult')
        except HTTPError, e:
            logger.error("SdCRequests - downloadFile - HTTP error: %s" % str( e.response.code))
            res = HTTPCallResult(e.response)
        if response:
            contentDispo = response.headers['Content-Disposition']
            logger.info('SdCRequests - downloadFile - contentDispo:%s' % str(contentDispo))
            m = re.match('^.*filename="(.*?)".*$',contentDispo)
            if m:
                filename=m.group(1)
                logger.info('SdCRequests - downloadFile - filename: %s' % filename)
                with open(dir + '/' + filename, 'wb') as handle:
                    try:
                        for block in response.iter_content(1024):
                            if not block:
                                break
                            handle.write(block)
                        
                    except HTTPError, e:
                        logger.error("SdCRequests - downloadFile - HTTP error: %s" % str( e.response.code))
                        res = HTTPCallResult(e.response)
        self.connPool.putConnection(conn)
        res.requestUrl=url
        res.type='DOWNLOAD'
        res.data=filename
        res.headers=session.headers
        return res

    def uploadFile(self,user,url,filename,form_fields={},headers={}):
        """
        Retrieve a connection from the pool, do the HTTP POST to upload a file using the corresponding Requests session and put back the connection in the pool
        """
        logger.info('SdCRequests - uploadFile - UPLOAD FILE %s' % filename)
        files = {'files':open(filename, 'rb')}
        for k,v in form_fields.items():
            files[k]=v
        conn=self.__getConnection(user,headers)
        session = conn.session
        logger.info('SdCRequests - uploadFile - URL POST: %s' % url)
        logger.debug( 'SdCRequests - uploadFile - Request HTTP Headers: ' + str(session.headers))
        res = None
        try:
            result = session.post(url, files=files)
            res = HTTPCallResult(result)
        except HTTPError, e:
            logger.error("SdCRequests - uploadFile - HTTP error: %s" % str( e.response.code))
            res = HTTPCallResult(e.response)
       
        res.requestUrl=url
        res.requestType='POST'
        res.requestData=filename
        res.headers=session.headers
        self.connPool.putConnection(conn)
        return res
    
    def getSdCHtml(self,user,urltrail,headers={}):
        if 'idm' in urltrail:
            url = self.env.idmURL
        else:    
            url = self.env.sdcURL + urltrail
        return self.get(user, url ,headers)
    
    def logout(self,user):
        res = self.getSdCHtml(user, urltrail = 'logout.html')
        return res
    
    def __getPageTitle(self,text):
        title=''
        text=text.replace('\n','').lower()
        m = re.match('^.*<title>(.*?)</title>.*$', text)
        if m: title=  m.group(1)
        return title
    
    def __is2FASetupLaterAllowed(self,text):
        """
        check if 2FA (2 Factor Authentication) "setup later" link is available to skip 2FA login process
        """
        text=text.replace('\n','')
        m = re.match('^.*"frmMain:txtTwoFAStatusLnkId".*$', text)
        if m: return True
        return False
    
    def __is2FAMandatory(self,text):
        """
        check if 2FA is activated
        """
        text=text.replace('\n','')
        #m = re.match('^.*"frmMain:pnl2FAActiveId".*$', text)
        m = re.match('^.*"frmMain:twoSVVerification:pnl2FAActiveId".*$', text)
        if m: return True
        return False
    
    def __getViewState(self,text):
        """
        Get the view state required by Java Server Faces
        """
        viewState=''
        text=text.replace('\n','')
        m = re.match('^.*"javax.faces.ViewState".*?value="(.*?)".*$', text)
        logger.debug( m)
        if m: viewState=  m.group(1)
        return viewState

    def getURL(self,url,session):
        res = None
        logger.info("SdCRequests - getURL - GET URL: " + url)
        try:
            res = session.get(url)
            logger.debug([(k,v) for k,v in session.headers.items()])
            logger.debug([(k,v) for k,v in session.cookies.items()])
            text=res.text.replace('\n','')
            logger.info("SdCRequests - getURL - PAGE TITLE: %s" %  self.__getPageTitle(text))
            #res = self.__handleSAMLResponse(r,session)
            #logger.info("PAGE TITLE: %s" %  self.__getPageTitle(res.text))
        except requests.exceptions.TooManyRedirects,err:
            logger.error('SdCRequests - getURL - TOO MANY REDIRECT error')
            print traceback.print_exc() 
            raise(err)
        except:
            logger.error('SdCRequests - getURL - unexpected error')
            traceback.print_exc()
            raise  
        return res

    def login(self,user):
        """
        Login to SdC via IDM
        """
        logger.info( 'SdCRequests - login - Do the login ...')
        logger.info( 'SdCRequests - login - user:%s' % user.email)
        http_header = self.env.loginHttpHeader
        http_header['Accept']='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        
        loginurl = self.env.loginUrl
        mainUrl = self.env.mainURL
        appurl = self.env.baseURL
        params = {
              'btSubmit':'Login',
              'password':user.password,
              'userid':user.email
        }
        # if multiprofile, add the profile id
        if user.isMultiprofile:
            params['profileId']=user.profileId
        logger.debug( params)
        session = requests.Session()
        
        session.headers=http_header
        
        logger.debug("SdCRequests - login - LOGIN Session header: %s" % str(session.headers))
        session.verify=False
        r=None
        # connecting to SdC
        try:
            logger.info('SdCRequests - login - Get Main URL: %s' % mainUrl)
            r = session.get(mainUrl)
            logger.debug([(k,v) for k,v in session.headers.items()])
            logger.debug([(k,v) for k,v in session.cookies.items()])
            logger.info("SdCRequests - login - PAGE TITLE: %s" %  self.__getPageTitle(r.text))
            logger.info('SdCRequests - login - URL (POST) the login form, URL: %s and params: %s' % (self.env.loginUrl, str(params)))
            r = session.post(loginurl, params)
            logger.info([(k,v) for k,v in session.headers.items()])
            logger.info([(k,v) for k,v in session.cookies.items()])
            logger.info("SdCRequests - login - PAGE TITLE: %s" %  self.__getPageTitle(r.text))
            if self.__is2FASetupLaterAllowed(r.text):
                # -- Post the 2 Factors Authentication "setup later" FORM 
                logger.info("SdCRequests - setuplater allowed")
                params={
                        'frmMain_SUBMIT':'1',
                        'javax.faces.ViewState':self.__getViewState(r.text),
                        'frmMain:txtTwoFAStatusLnkId':'frmMain:txtTwoFAStatusLnkId'
                        }     
                logger.info('SdCRequests - login - URL (POST) 2FA setup later: %s,%s' %(self.env.twoFAURLSetup, params))
                r = session.post(self.env.twoFAURLSetup, params)
            elif self.__is2FAMandatory(r.text):
                # -- Post the 2FA token FORM
                logger.info("SdCRequests - 2FA mandatory")
                twoFACodeId=None
                with MailServer(self.env) as mailserver:
                    twoFACodeId =  mailserver.GetOTPFromEmail(user.email,"2-step verification code")
                params={
                        'frmMain_SUBMIT':'1',
                        'frmMain:twoSVVerification:twoFACodeId':twoFACodeId,
                        'javax.faces.ViewState':self.__getViewState(r.text),
                        'frmMain:twoSVVerification:cmdVerifyCodeIdm':'frmMain:twoSVVerification:cmdVerifyCodeIdm'
                        }     
                logger.info('SdCRequests - login - URL (POST) 2FA code: %s, %s' % (self.env.twoFAURLVerif, params))
                r = session.post(self.env.twoFAURLVerif, params)
                logger.info("SdCRequests - login - PAGE TITLE: %s" %  self.__getPageTitle(r.text))
            res = self.__handleSAMLResponse(r,session)
            logger.info("SdCRequests - login - PAGE TITLE: %s" %  self.__getPageTitle(res.text))

        except requests.exceptions.TooManyRedirects,err:
            logger.debug('SdCRequests - login - TOO MANY REDIRECT error, but skipping because connection is done')
            pass
        except:
            logger.error( 'SdCRequests - login - unexpected error')
            print traceback.print_exc()  

        # connecting to application
        
        try:
            logger.info( 'SdCRequests - login - URL (GET): %s' % appurl)
            r = self.getURL(appurl,session)
            logger.debug([(k,v) for k,v in session.headers.items()])
            logger.debug([(k,v) for k,v in session.cookies.items()])
            logger.info("SdCRequests - login - PAGE TITLE: %s" %  self.__getPageTitle(r.text))
        except requests.exceptions.TooManyRedirects,err:
            logger.error( 'SdCRequests - login - TOO MANY REDIRECT error')
            print traceback.print_exc() 
            raise(err)
        except:
            logger.error('SdCRequests - login - unexpected error')
            print traceback.print_exc()  
            raise  
        self.connPool.putConnection(HTTPConnection(user,session))
        logger.info('SdCRequests - login - User is logged into KYC')
        return r

class RESTRequest(HTTPRequest):
    """
    Extends the HTTPRequest in order to do REST calls
    """
    def __init__(self, environment):
        HTTPRequest.__init__(self, environment)
    def getJson(self,user,urltrail,additionnal_headers={}):
        http_header = self.env.httpHeader
        http_header['Accept']='application/json, text/plain, */*'
        for k,v in  additionnal_headers.items():
            http_header[k]=v
        url = self.env.url + urltrail
        res = self.get(user,url,http_header)
        return res
    def postJson(self,user,urltrail,data={},additionnal_headers={}):
        datastring=json.dumps(data)
        http_header = self.env.httpHeader
        http_header['Accept']='application/json, text/plain, */*'
        http_header['Content-Type']='application/json;charset=utf-8'
        for k,v in  additionnal_headers.items():
            http_header[k]=v
        url = self.env.url + urltrail
        res = self.post(user,url,datastring,http_header)
        return res
    def downloadFile(self,user,urltrail,dir,additionnal_headers={}):
        http_header = self.env.httpHeader
        http_header['Accept']="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        for k,v in  additionnal_headers.items():
            http_header[k]=v
        url = self.env.url + urltrail
        res = super(RESTRequest,self).downloadFile(user,url,dir,http_header)
        return res
    def uploadFile(self,user,urltrail,filename,form_fields,additionnal_headers={}):
        http_header = self.env.httpHeader
        http_header['Accept']="application/json, text/javascript, */*; q=0.01"
        http_header['X-Requested-With']='XMLHttpRequest'
        for k,v in  additionnal_headers.items():
            http_header[k]=v
        url = self.env.url + urltrail
        res = super(RESTRequest,self).uploadFile(user,url,filename,form_fields,http_header)
        return res
class HTTPCallResult():
    def __init__(self,result):
        self.error = None
        self.returnCode=result.status_code
        if self.returnCode != 200:
            self.error = self.returnCode
        self.status = ''
        self.result=result
        self.text=result.text
        self.data=None
        self.requestUrl=''
        self.requestType=''
        self.requestData=[]
        self.requestHttpHeader={}
        self.cookies=[]
        text=self.text
        #print text # activate only for debug
        try:
            if text[:5]==")]}',":
                text=text[5:] # don't know why they put ")]}'," before the json string, so remove the first five characters before loading the json
            data = json.loads(text)
            self.type='JSON'
            self.data=data
        except:
            self.type='HTML'
        if self.error :
            self.status = 'FAILURE'
            
        else:
            self.status = 'SUCCESS'

class ConnectionException(Exception):
    def __init__(self, value):
        self.error = value.error
        self.html = value.text
    def __str__(self):
        return "HTTP Error code: %s - HTML: %s" % (self.error,self.html)
class HTTPCallException(Exception):
    def __init__(self, res):
        self.error = res.error
        self.html = res.text
        self.data = res.data
        self.type = res.type
        self.res = res
    def __str__(self):
        if self.type=='HTML':
            return "HTTP Error code: %s - HTML: %s" % (self.error,self.html)
        if self.type=='JSON':
            return "HTTP Error code: %s - JSON: %s" % (self.error,self.data)

        

if __name__=='__main__':
    from KYCENV import KYCEnvironment
    env = KYCEnvironment.getEnvironment('PAC')
    env.loadUserProfileFromLdap()
    request = RESTRequest(env)
    user = env.getSdCUser('pac.kyc.submitter1@citi.com')
    res = request.getJson(user, 'resources/v1/userprofile')
    print res.type + ':' + res.text
#     res = request.postJson(user,'resources/v1/entity/995001/folder/update',data={"categoryCode":"IOC","data":{"INSTITUTION_STATUS":""},"sourced":{},"notApplicable":{},"documentsToAdd":[],"documentsToRemove":[],"documentLinksToAdd":[],"documentLinksToRemove":[]})
#     print res.data
#     res = request.uploadFile(user, 'resources/v1/entity/995001/folder/IOC/document/upload',env.documentPath + 'document-English.pdf',form_fields={'documentTypeId':'1102731','language':'English'})
#     print res.status
    
    
