import ldap
import csv,sqlite3,os 
from SdCModel import SdCIDMUser
import paramiko,socket, uuid
import sys, json, re
import inspect, pickle
#import cx_Oracle
import traceback
from SdCUtils import SdCSSH,LogFunctionAccess
import logging

logger = logging.getLogger("SdCSQLUtils")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)

def LogAccess(fn):
    return LogFunctionAccess(fn,logger)


@LogAccess
def get_script_dir(follow_symlinks=True):
    if getattr(sys, 'frozen', False): 
        path = os.path.abspath(sys.executable)
    else:
        path = inspect.getabsfile(get_script_dir)
    if follow_symlinks:
        path = os.path.realpath(path)
    return os.path.dirname(path)

class SdCSQLConfigLoader():
    @LogAccess  
    def __init__(self,configFileDir=None):
        if not configFileDir:
            self.sqlLocalDir=get_script_dir() + os.sep + "SQLScripts" + os.sep      
        else:
            self.sqlLocalDir=configFileDir + os.sep 
    @LogAccess    
    def loadSQLConfigFile(self,configFilename):
        config={}
        with open(self.sqlLocalDir + configFilename + '.config','r') as configFileHdlr:
            lineType = ""
            while 1:
                line = configFileHdlr.readline()
                if not line: break
                if "- PARAMS -" in line:
                    config['params']=""
                    lineType='params'
                    continue
                elif "- COLUMNS -" in line:
                    config['columns']=""
                    lineType='columns'
                    continue
                elif "- SQL -" in line:
                    config['sql']=""
                    lineType='sql'
                    continue
                config[lineType] +=line 
        configDict={}
        configDict["params"] = config["params"].strip().split("\n")
        configDict["columns"] = config["columns"].strip().split("\n")
        configDict["sql"] = config["sql"].strip().split("\n")
        if not "".join(configDict["params"]): configDict["params"]=[] 
        if not "".join(configDict["columns"]): configDict["columns"]=[] 
        logger.debug(json.dumps(configDict, sort_keys=True, indent=4, separators=(',', ': ')))
        return configDict    

# class SQLViaCXOracle():
#     def __init__(self,dbConParams, configFileDir=None):
#         self.sid = dbConParams['sid']
#         self.dbhost = dbConParams['server']
#         self.dbport = dbConParams['port']
#         self.dbuser = dbConParams['user']
#         self.dbpassword = dbConParams['password']
#         self.conString="%s/%s@%s:%s/%s" % (self.dbuser,self.dbpassword,self.dbhost,self.dbport,self.sid)
#         self.sqlLocalDir=get_script_dir() + os.sep + "SQLScripts" + os.sep + "ConfigFiles" + os.sep
#         self.con=None
#         self.returnDict=True
#         self.configLoader=SdCSQLConfigLoader(configFileDir)
#     def init(self):
#         print 'Opening connection ...'
#         try:
#             self.con = cx_Oracle.connect(self.conString)
#             print 'Connected to ', self.conString
#         except:
#             print 'Cannot open connection to db with params:', self.dbhost,self.dbport,self.dbuser
#             raise
#     def release(self):
#         print 'Closing connection ...'
#         if self.con: self.con.close()
#         print 'Done'
#     def __enter__(self):
#         self.init()
#         return self
#     def __exit__(self, type, value, traceback):
#         self.release()
#     def runPreparedSQL(self,configFilename, values=[]):
#         config = self.configLoader.loadSQLConfigFile(configFilename)
#         paramDict={}
#         if 'params' in config.keys(): 
#             params = config['params']
#             if len(params)!=len(values):
#                 print 'number of values should correspond to number of params', params, values
#                 return []
#             else:
#                 paramDict = dict(zip(params,values))
#         if values and not params:
#             print 'no params'
#         if 'columns' in config.keys(): 
#             columns = config['columns']
#         if 'sql' in config.keys(): 
#             sql = '\n'.join(config['sql'])
#         if not sql:
#             print 'no sql !!!'
#             return []
#         if '[COLUMNS]' in sql and not columns:
#             print 'missing columns in config file'
#             return []
#         if columns and '[COLUMNS]' not in sql:
#             print 'missing columns in sql file'
#             return []
#         aliasedColumns=[field.upper().split(' AS ')[-1] for field in columns]
#         sqlColumns=[field.upper().split(' AS ')[0] for field in columns]
#           
#           
#    
#         sqlret=[]
#         con = None
#         cur = None
#         sqlStatements = sql.split(';')
#            
#         sql = sqlStatements[0].replace('[COLUMNS]',",".join(sqlColumns))
#         sql = sql.replace('FROM ','FROM ' + self.dbuser + '.')
#         for k,v in paramDict.items():
#             sql = sql.replace("${%s}" % k,v)
#         print 'SQL:', sql
#         try:
#             con = self.con
#             cur = con.cursor()
#             sqlret = cur.execute(sql).fetchall()
#         except:
#             print traceback.print_exc() 
#             if cur: cur.close()
#             if con: con.close()
#             raise
#         finally:
#             if cur: cur.close()
#         if self.returnDict and columns:
#             return [dict(zip(aliasedColumns,line)) for line in sqlret]
#         else:
#             return sqlret    

class SQLViaSSH(SdCSSH):
    @LogAccess
    def __init__(self,sshConParams, dbConParams,configFileDir=None):
        SdCSSH.__init__(self,sshConParams)
        self.sid = dbConParams['sid']
        self.oracle_home = dbConParams['oracle_home']
        self.shell_query_template_file='sqlCommandTemplate.sh'
        self.dbuser = dbConParams['user']
        self.dbpassword = dbConParams['password']
        if configFileDir:
            self.sqlLocalDir=configFileDir
            print self.sqlLocalDir
        else:
            self.sqlLocalDir=get_script_dir() + os.sep + "SQLScripts" + os.sep
        logger.log(logging.DEBUG, "SdCSQLUtils - SQL config files directory: " + self.sqlLocalDir)
        self.remotedir='/home/' + sshConParams['user'] + '/pacsql/'
        logger.log(logging.DEBUG, "SdCSQLUtils - ssh files target directory: " + self.remotedir)
        self.returnDict=False
        self.configLoader=SdCSQLConfigLoader(configFileDir)
    @LogAccess
    def runPreparedSQL(self,configFilename,values=[],recreate=False):
        config = {}
        params=[]
        columns=[]
        sql=''
        config=self.configLoader.loadSQLConfigFile(configFilename)
        logger.log(logging.INFO, "SdCSQLUtils - configLoader has been called")
         
        if 'params' in config.keys(): 
            params = config['params']
            if len(params)!=len(values):
                logger.log(logging.ERROR, 'number of values should correspond to number of params PARAMS: %s, VALUES: %s' %(str(params), str(values)))
                return []
        if values and not params:
            logger.log(logging.ERROR, 'no params')
        if 'columns' in config.keys(): 
            columns = config['columns']
        if 'sql' in config.keys(): 
            sql = '\n'.join(config['sql'])
        if not sql:
            logger.log(logging.ERROR, 'no sql !!!')
            return []
        if '[COLUMNS]' in sql and not columns:
            logger.log(logging.ERROR, 'missing columns in config file')
            return []
        if columns and '[COLUMNS]' not in sql:
            logger.log(logging.ERROR, 'missing columns in sql file')
            return []
        aliasedColumns=[field.upper().split(' AS ')[-1] for field in columns]
        sqlColumns=[field.upper().split(' AS ')[0] for field in columns]
        filename = configFilename + '.sh'
        sqlret =  self.executeSQL(sql,params,values, sqlColumns,filename,recreate)
        logger.log(logging.INFO, 'SdCSQLUtils - sql return: %s' % str(sqlret))
        if self.returnDict and columns:
            return [dict(zip(aliasedColumns,line)) for line in sqlret]
        else:
            return sqlret
    @LogAccess
    def executeSQL(self,sql,params=[],values=[], columns=[],filename='',recreate=False):
        permanentFlag = False
        createFile = True
        if filename:
            permanentFlag = True
        else:    
            filename = 'TEMPSQL_' + str(uuid.uuid4()).replace('-','_') + '.sh'
        fileContent = ''
        lines = []
        with open(self.sqlLocalDir + os.sep + "Template" + os.sep + self.shell_query_template_file,'r') as sqlfile:
            fileContent=sqlfile.read()
        strParams = ""
        strColumn = ""
        for i in xrange(len(params)):
            strParams +="%s=\\$%d\n" % (params[i],i+1)
        strColumn = " || '|' || ".join(columns)
        sql = sql.replace('[COLUMNS]',strColumn)
        sql = sql.replace('$','\$')
        fileContent = fileContent.replace('[PARAMS]',strParams)
        fileContent = fileContent.replace('[SID]',self.sid)
        fileContent = fileContent.replace('[ORACLE_HOME]',self.oracle_home)
        fileContent = fileContent.replace('[USER]',self.dbuser)
        fileContent = fileContent.replace('[PASSWORD]',self.dbpassword)
        fileContent = fileContent.replace('[SQL]',sql)
        
        lines = fileContent.split('\n')
        sqlResult = []
        error=''
        try:
            if permanentFlag and not recreate:
                # verify if the file already exists
                cmd = 'ls %s' % self.remotedir + filename
                stdout = self.executeCommand(cmd,forceExec=True)
                if stdout.read():
                    createFile=False
            if createFile:
                cmd = 'rm %s' % self.remotedir + filename
                stdout = self.executeCommand(cmd)        
                for line in lines:
                    cmd = 'echo "%s" >> %s' % (line,self.remotedir + filename)
                    stdout = self.executeCommand(cmd)
                cmd = 'chmod 700 %s' % self.remotedir + filename
                stdout = self.executeCommand(cmd)
            cmd = 'sh %s%s' % (self.remotedir + filename,''.join([' "%s"' % str(v) for v in values]))
            stdout = self.executeCommand(cmd)
            if stdout:
                sqlResult=[line[:-1].split("|") for line in stdout.readlines()]
        except:
            logger.log(logging.ERROR, "error: %s" % str(sys.exc_info()))
        finally:
            if not permanentFlag:
                cmd = 'rm %s' % self.remotedir + filename
                stdout = self.executeCommand(cmd)
        return sqlResult

if __name__=='__main__':
    from KYCENV import KYCEnvironment
    env = KYCEnvironment.getEnvironment('PAC_CI')
    res = []
    #with SQLViaCXOracle(env.dbConnectionParams) as sdcSQL:
    with SQLViaSSH(env.sshDBServerConnectionParams, env.dbConnectionParams) as sdcSQL:
        res = sdcSQL.runPreparedSQL('KYC_Count_Event_for_Access_Mgmt',['RBOSGB22XXX','SOGE','ACCESS_REQUESTED','requestingEntities',])
    print res
    
    
