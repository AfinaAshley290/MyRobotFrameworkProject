import poplib
import email
from email import parser
from email import MIMEBase, MIMEMultipart, MIMEText, Encoders, Header, message_from_string, Charset
import quopri
import logging
import re

logger = logging.getLogger("SdCMail")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt)
logger.addHandler(ch)

class MailServer():
    def __init__(self,env):
        self.ip_address = env.MAIL_SERVER_IP_ADDRESS
        self.user = env.MAIL_SERVER_USER
        self.password = env.MAIL_SERVER_PASSWORD
        self.connection = None
    def init(self):
        self.getConnection()
    def getConnection(self):
        if not self.connection:
            logger.info( "Connect to mail server %s as %s" % (self.ip_address,self.user))
            self.connection = poplib.POP3_SSL(self.ip_address)
            self.connection.user(self.user)
            self.connection.pass_(self.password)
        return self.connection
    def releaseConnection(self):
        try:
            logger.info( "release connection to mail server")
            connection.quit() 
            logger.info("connection released")
        except:
            pass
        self.connection = None
    def __del__(self):
        self.releaseConnection()
    def __enter__(self):
        self.init()
        return self
    def __exit__(self, type, value, traceback):
        self.releaseConnection()
    
    def GetEmailBodyFromLastReceivedEmail(self,UserEmail):
    #Get total number of messages and size"
        connection = self.getConnection()
        (numMsgs, totalSize) = connection.stat()
        email_retrieve_string = ""
        logger.debug("numMsgs: %s" % str(numMsgs))
        if numMsgs == 0:
            logger.info("No Mails in mailbox")
        else:
            # -- if there are messages in email
            match_number=0
            # -- next cycle is looking for match of User email in email folder
            while numMsgs>0:        
                email_retrieve = connection.retr(numMsgs)[1]
                email_retrieve_string = str(email_retrieve)
                # -- I am looking for match of message with userEmail value
                match = re.search(UserEmail,email_retrieve_string)
                if match:
                    logger.debug( "this is it! Body of the message is: %s" % email_retrieve_string)
                    m_body = email_retrieve_string
                    # -- I am calculating how many matches I have
                    match_number=match_number+1
                    numMsgs = 0
                else:
                    logger.debug("I didn't find match")
                    numMsgs=numMsgs-1
            logger.debug( "number of positive match is %s" % str(match_number))
        return email_retrieve_string
    
    def GetLinkFromEmail(self,UserEmail,subject):
        connection = self.getConnection()
        # -- Get total number of messages and size"
        link=""
        (numMsgs, totalSize) = connection.stat()
        logger.debug("numMsgs: %s" % str(numMsgs))
        if numMsgs == 0:
            logger.info("No Mails in mailbox")
        else:
            # -- if there are messages in email
            match_number=0
            twenty_messages=500
            while twenty_messages>0:
                email_retrieve = connection.retr(numMsgs)[1]
                email_retrieve_string = str(email_retrieve)
                # -- I am looking for match of message with userEmail value
                match = re.search(UserEmail,email_retrieve_string)
                if match:
                    # -- I am calculation how many matches I have
                    match_number=match_number+1
                    # -- print "this message include your string you find", connection.top(numMsgs,20)
                    message=str(connection.top(numMsgs,20))
                    # -- below I am searching for link in message - xpath represents link (http or ftp or https)
                    match_subject=re.search(subject,message)
                    if match_subject:
                        match1=re.search("(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?",message)
                        if match1:
                            logger.debug("this is link you have to use for reset password %s" % str(match1.group()))
                            twenty_messages=0
                            #I return link I extracted from message in previous steps
                            link =  match1.group()
                        else:
                            logger.debug( "in this email there is no link")
                    # -- need to add condition for stopping search
                    # -- extract link
                    else:
                        numMsgs = numMsgs-1
                        twenty_messages=twenty_messages-1
                else:
                    logger.debug("I didn't find match")
                    numMsgs=numMsgs-1
                    twenty_messages=twenty_messages-1
            logger.debug("number of positive match is %s" % str(match_number))
            
            return link
       
    def GetOTPFromEmail(self,UserEmail,subject):
        connection = self.getConnection()
        # -- Get total number of messages and size"
        (numMsgs, totalSize) = connection.stat()
        logger.debug("numMsgs: %s" % str(numMsgs))
        if numMsgs == 0:
            logger.info( "No Mails in mailbox")
            return "No Mails in mailbox"
        else:
            # -- if there are messages in email
            match_number=0
            messages_checked=0
            while numMsgs>0:
                email_retrieve = connection.retr(numMsgs)[1]
                email_retrieve_string = str(email_retrieve)
                # -- I am looking for match of message with userEmail value
                match = re.search(UserEmail,email_retrieve_string)
                if match:
                    # -- I am calculation how many matches I have
                    match_number=match_number+1
                    logger.debug("this message include your string you find %s" % str(connection.top(numMsgs,20)))
                    logger.debug("this is email content %s" % email_retrieve_string)
                    # -- message=str(connection.top(numMsgs,20))
                    message=str(email_retrieve_string)
                    # -- below I am searching for OTP in message - 
                    match_subject=re.search(subject,message)
                    if match_subject:
                        logger.debug(message)
                        match1=re.search(">([0-9]{6})",message)
                        otp = match1.group()[1:7]
                        logger.debug("otp= %s" % str(otp))
                        connection.dele(numMsgs)
                        return otp
                    else:
                        numMsgs = numMsgs-1
                else:
                    logger.debug("I didn't find match")
                    messages_checked=messages_checked+1
                    numMsgs=numMsgs-1
                    if messages_checked>1000:
                        logger.info("Sorry I checked: %s messages but couldn't find your message" % str(messages_checked))
                        numMsgs=0
            logger.info("number of positive match is %s" % str(match_number))


    def DeleteEmail(self,UserEmail):
        connection = self.getConnection()
        # -- Get total number of messages and size"
        (numMsgs, totalSize) = connection.stat()
        logger.debug("numMsgs: %s" % str(numMsgs))
        if numMsgs == 0:
            logger.info("No Mails in mailbox")
        else:
            # -- if there are messages in email
            match_number=0
            messagesTodelete=26800
            while messagesTodelete>0:
                    connection.dele(numMsgs)
                    numMsgs=numMsgs-1
                    #print "I am here"
                    messagesTodelete=messagesTodelete-1
                       
            logger.info("number of positive match is %s" % str(match_number))

if __name__=="__main__":
    from SdCENV import Environment
    with MailServer(Environment.getEnvironment('SI')) as server:
        print server.GetOTPFromEmail('pac.kyc.submitter1@citi.com',"2-step verification code")
