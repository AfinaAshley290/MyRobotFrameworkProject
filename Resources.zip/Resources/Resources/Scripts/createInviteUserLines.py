templateInviteUser = 'RPC Invite User Assign Roles To All Entities    %s    %s    %s'
letter='RD'
firstname='abchina'
group='${GROUP_HEAD_%s}' % letter
roles=['administrator', 'submitter', 'approver', 'viewer', 'requester', 'granter', 'swppublisher', 'swpviewer', 'swprequester', 'swpgranter']
for role in roles:
    for i in xrange(1,3):
        roleName = role.replace('swp','SWIFT Profile ')
        roleName = ' '.join([word[0].upper() + word[1:] for word in roleName.split(' ')])
        print '    ' + templateInviteUser % (group,role+'_'+letter+str(i),roleName)
