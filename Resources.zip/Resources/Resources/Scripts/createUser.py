templateDefineUser = '${%s_%s%d_user}    pac.kyc.%s%d%s'
templateDefineUserName = '${%s_%s%d_user}    %s %s%d'
letter='RD'
firstname='abchina'
domain='@abchina.com'
roles=['administrator', 'submitter', 'approver', 'viewer', 'requester', 'granter', 'swppublisher', 'swpviewer', 'swprequester', 'swpgranter']
for role in roles:
    for i in xrange(1,3):
        print templateDefineUser % (role,letter,i,role,i,domain)
        print templateDefineUserName % (role,letter,i,firstname,role,i)
