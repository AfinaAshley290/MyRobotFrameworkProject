import os

variables_CI_PAC = {'URL_RPC':'https://bekyci02:30133/kyc-xmlrpc/xml-rpc/'                    
                    }


variables_PAC = {'URL_RPC':'https://bekyci02:30134/kyc-xmlrpc/xml-rpc/'
                    }

def get_variables(env):
    if env == 'CI-PAC':    
        os.environ["ENV"] = "CI-PAC"
        return variables_CI_PAC      
    elif env == 'PAC':
        os.environ["ENV"] = "PAC"
        return variables_PAC
    else:
       print 'error - unknown environment: ' + env       

