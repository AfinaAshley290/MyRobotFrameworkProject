#!/bin/sh
# KYC PAC script to operate a database from the shell
[PARAMS]

export ORACLE_SID=[SID]
export ORACLE_HOME=[ORACLE_HOME]
export PATH=\$ORACLE_HOME/bin:/bin:/sbin:/usr/bin:/usr/sbin

        sqlplus -s [USER]/[PASSWORD]  <<EOF  | sed '/^$/d'
set pagesize 0;
set line 4000 head off feedback off;
set tab off
set trimspool on
[SQL]

EOF