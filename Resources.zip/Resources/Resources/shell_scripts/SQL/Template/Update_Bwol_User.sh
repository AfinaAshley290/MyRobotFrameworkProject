#!/bin/sh
# KYC PAC script to operate a database from the shell

USER_EMAIL = $1;

export ORACLE_SID=KYCDB
export ORACLE_HOME=/opt/oracle/product/12.1.0.2/dbhome_1
export PATH=$ORACLE_HOME/bin:/bin:/sbin:/usr/bin:/usr/sbin
        sqlplus -s KYCDB_PAC/SdC9876-  <<EOF  | sed '/^$/d'
set pagesize 80;
set line 300 head off  feedback off;

UPDATE USERS u set BWOL_LICENSE='Y' where u.EMAIL_ADDRESS='${USER_EMAIL}';
COMMIT WORK ;

exit;
EOF